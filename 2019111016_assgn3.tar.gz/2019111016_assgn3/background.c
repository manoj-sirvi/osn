#include "headers.h"
//#include <sys/wait.h>
void back_gro(char **argv, int back)
{
    // printf("%d", back);
    pid_t pid, u;
    pid = fork();
    job_sequence[jobs].pid = pid;
    // printf("pid%d\n", pid);
    job_sequence[jobs++].path = argv[0];

    //  printf("")
    int status; // = (int *)calloc(1000);
    if (pid < 0)
    {
        perror("Error");
        return;
    }
    int background = 0;
    if (pid == 0)
    {

        //  printf("%d\n", status);
        // if (status < 0)
        //   return;
        execvp(argv[0], argv);
        exit(0);
    }
    if (back)
    {
        // printf("enter");
        signal(SIGCHLD, handler);
    }
    else
    {
        wait(NULL);
    }

    // wait(NULL);
}