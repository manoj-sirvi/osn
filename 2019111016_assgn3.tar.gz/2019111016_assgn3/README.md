# shell
 Run a shell in c

 # makefile
 1). Run to shell first run 'make'
 2). then run './shell' to enter on console

 # file details

 1). 'shell.c' -: This file run the console for infinite time while it not face   error. and it check for command that which has to run.

 2). 'get_cwd.c' -: In this get the shell directory and change the path of console where we are currently.

 3). 'read_splite.c' -: this file read the user input and parse it into multiple strings.and also reposible to print prompt.

 4). 'background.c' -: This file handle tha background and frontground process and print appropriate message what happen with background process through signal.

 5). 'cd.c' -: handle cd command

 6). 'pwd.c' -: print the path of current working directory

 7). 'echo.c' -:handle echo command

 8). 'handle.c' -: define handler of signal function

 9). 'histor.txt'-: store history in text file

 10). 'history.c' -: store history and print history

 11). 'ls_flag.c' -: implement ls command with flags

 12). 'pinfo.c' -: implemnt of pinfo command which is given a information about process

 13). 'assign_open_close.c' -: it is doing redirection work for command

 14). 'assign_redirect.c' -: checking for redirection

 15). 'cd_1.c' -: print last directory

 16). chech.c -: checking in input line for piping and redirection and check for pipe+redierction

 17). 'excute.c' -: recuting foreground command

 18).  'fg.c' -: taking backgroung process in foreground process

 19). 'job.c' -: printing jobs which are running in background

 20). 'kjob_done.c' -: kill the job and also remove completed jobs

 21). 'overkill.c' -: kill all background process

 22). 'set_unset.c' -: set the value for global variable and remove it.

 23). 'state.c' -: implementing bg command
 
  # command can excuted

  1). ls and it's flag
  2) pwd
  3) cd
  4) echo
  5) background process
  6) pinfo
  7) history
  8) bg
  9) fg
 10) jobs
 11) cd -
 12) redirection
 13) piping
 14) overkill
 15) quit
 16) kjob
 17) setenv
 18) unsetenv
 19) ctrl - z
 20) ctrl - d
 21) ctrl - c
 
  
  
