#include "headers.h"

void cd_sp(char **argv)
{
    int f_prime = 0;
    if (strcmp(argv[0], "cd") == 0 && strcmp(argv[1], "-") == 0)
        f_prime = 1;
    if (!f_prime)
        return;
    else
    {
        f_f = 1;
        if (for_cd == 0)
        {
            return;
        }
        else
        {
            printf("%s\n", store_pre_dire);
        }
    }
}