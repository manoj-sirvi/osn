#include "headers.h"

char *get_shell_dire()
{
    char *direp = (char *)malloc(1000);
    getcwd(direp, 1000);
    if (direp == NULL)
    {
        perror("Error");
    }
    return direp;
}
char *check1(char *dire1, char *dire2)
{
    int len1 = strlen(dire1);
    int len2 = strlen(dire2);
    //  printf("%s    %s\n", dire1, dire2);
    //printf("%d %d \n", len1, len2);
    char *ans = (char *)calloc(1000, 1);
    // ans = NULL;
    //free(ans);
    //char *ans = (char *)malloc(1000);
    if (len1 > len2)
    {
        ans = dire2;
    }
    else
    {
        // printf("%ld\n", strlen(ans));
        ans[0] = '~';
        for (int i = len1; i < len2; i++)
        {
            ans[i - len1 + 1] = dire2[i];
            //printf("enter");
        }
    }
    // printf("ans=%sans1\n", ans);
    return ans;
}