#include "headers.h"

void delete_ji(int pid)
{
    int i;
    int count = 0;
    for (i = 0; i < jobs; i++)
    {
        if (pid == job_sequence[i].pid)
        {
            continue;
        }
        else
        {
            job_sequence[count].pid = job_sequence[i].pid;
            job_sequence[count].path = job_sequence[i].path;
            count++;
        }
    }
    jobs--;
}
void fg(int num)
{
    
    if (num > jobs)
    {
        printf("NO JOB EXIST\n");
        return;
    }
    int status, pid;
    pid_t p1 = getpid();
    pid = job_sequence[num - 1].pid;
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    tcsetpgrp(0, getpgid(pid));
    kill(pid, SIGCONT);
    waitpid(pid, NULL, WUNTRACED);
    tcsetpgrp(0, p1);
    signal(SIGTTOU, SIG_DFL);
    signal(SIGTTIN, SIG_DFL);
    delete_ji(pid);
}
