#include "headers.h"

int main()
{
    int status = 1;
    for_cd = 0;
    //char *dire1 = (char *)malloc(1000);
    dire1 = get_shell_dire(); //shell present directory
    path_of_history = get_shell_dire();
    strcat(path_of_history, "/histor.txt");
    //printf("%s\n", path);
    total_store_history = 0;
    // for (int i = 0; i < 25; i++)
    //   strcpy(hist[i], "\0");
    // printf("%s", dire1);
    global_pid = -1;
    jobs = 0;
    signal(SIGINT, ctrl_c);
    signal(SIGTSTP, ctrl_z);

    f_f = 0;
    printf("hello! welcome to shell\n");
    while (status)
    {
        printf("\n");
        out_from_cd = 0;
        get_name();
        char *cwd = (char *)malloc(1000);
        getcwd(cwd, 1000);
        f_f = 0;

        char *final_dire = check1(dire1, cwd); //current working directory

        printf("%s$ ", final_dire);

        //   printf("ans");
        // printf("%s %s\n", dire1, cwd);
        char *line = read1();
        //  printf("%s\n", line);
        //printf("%ld\n", strlen(line));
        int a = strlen(line);
        if ((a - 1) < 0)
        {
            // printf("enter\n");
            status = 0;
            continue;
        }
        if (strcmp(line, "\n") == 0)
        {
            // printf("enter\n");
            continue;
        }

        store_history(line);
        break_command(line);

        // printf("%s\n ", cwd);
        char **argv = struc.str;
        // int i = 0;
        val = 0;

        // int i = 0;
        // while (argv[i] != NULL)
        // {
        //     //printf("%s\n", argv[i]);
        //     i++;
        // }
        int value = struc.temp;
        // printf("%d", struc.temp);
        int turn = 0;

        //  char *str;
        //strcpy(str, argv[turn]);
        int flag = 0;
        //  printf("sdjcgsd");

        main_flag = 0;
        set1(argv);
        unset1(argv);
        kjob(argv);
        // printf("%d\n", jobs);
        over_kill(argv);
        print_job(argv);
        bg(argv);
        if (argv[value - 1][0] == '&')
        {
            f_f = 1;
            flag = 1;
            argv[value - 1] = NULL;
        }
        if (strcmp(argv[0], "quit") == 0)
        {
            status = 0;
            continue;
        }

        if (!strcmp(argv[0], "history"))
        {
            f_f = 1;
            int p;
            if (argv[1] != NULL)
            {
                p = atoi(argv[1]);
            }
            else
            {
                p = 0;
            }
            //   printf("%d %d\n", p, total_store_history);
            print_history(p);
        }
        //  printf("%d\n", flag);
        //  printf("\n%d\n", f_f);
        fun(argv);
        // printf("out\n");
        // printf("enter\n");
        cd_sp(argv);
        // printf("tree\n");
        //printf("\n%d\n", f_f);
        //printf("final\n");
        // printf("\nout\n");
        // printf("%d %d\n", flag, main_flag);
        if (!flag && !main_flag)
        {
            // printf("hii\n");
            change_dir(argv); // cd command
            //printf("dyusgc");
            echo_cal(argv); // implement echo coommand
            get_pwd(argv);  // implement pwd command
            //printf("tree\n");
            int arr[10] = {0};              // arr[0]=NULL ,arr[1]="-l",arr[2]="-a",arr[3]="(-al)(-la)(-a -l)";
                                            //  printf("cdcdcdc\n");
            if (strcmp(argv[0], "ls") == 0) // ls command with flags
            {
                f_f = 1;
                char *step = (char *)calloc(1000, 1);
                int i = 1;
                while (argv[i] != NULL)
                {

                    if (strcmp(argv[i], "-l") == 0 || strcmp(argv[i], "-a") == 0 || !(strcmp(argv[i], "-al") || !(strcmp(argv[i], "-la"))))
                    {
                        i++;
                        continue;
                    }
                    strcat(step, argv[i]);
                    i++;
                }
                // printf("a%sb\n", step);
                i = 1;
                if (strlen(step) == 0)
                {
                    // printf("enter");
                    step = ".";
                }
                while (argv[i] != NULL)
                {
                    if (strcmp(argv[i], "-l") == 0)
                        arr[1]++;
                    if (strcmp(argv[i], "-a") == 0)
                        arr[2]++;
                    if (strcmp(argv[i], "-al") == 0 || strcmp(argv[i], "-la") == 0)
                        arr[3]++;
                    i++;
                }
                // printf("%d %d %d ", arr[2], arr[1], arr[3]);
                //printf("%s\n", step);
                if ((arr[1] && arr[2]) || arr[3])
                {
                    fun_lsal(step);
                }
                else
                {
                    if (arr[1] && !arr[2])
                        fun_lsl(step);
                    //printf("jxkc");
                    else if (arr[2] && !arr[1])
                        fun_lsa(step);
                    else
                    {
                        fun_ls(step);
                    }
                }
            }
            // printf("hello\n");
            if (!strcmp(argv[0], "pinfo"))
            {
                f_f = 1;
                int value = 1;
                int sum = 0;
                if (argv[1] != NULL)
                {
                    // printf("%s\n", argv[1]);
                    int value = atoi(argv[1]);
                    // for (int i = strlen(argv[1]) - 1; i >= 0; i--)
                    // {
                    //     printf("%c\n", argv[1][0]);
                    //     sum += (value * (argv[1][i] - '0'));
                    //     value *= 10;
                    // }
                    //  printf("value\n");
                    fun_pinfo(argv, value);
                }
                else
                {
                    //  printf("enter");
                    fun_pinfo(argv, 0);
                }
            }
        }
        // printf("%d\n", f_f);
        if (strcmp(argv[0], "fg") == 0)
        {
            f_f = 1;
            int no = atoi(argv[1]);
            fg(no);
        }
        if (flag)
        {
            back_gro(argv, flag);
        }
        if (f_f == 0)
        {
            // printf("enter\n");
            current_fg_name = (char *)calloc(1000, 1);
            strcpy(current_fg_name, argv[0]);
            excute_command(argv);
        }
        // printf("no error\n");
        if (out_from_cd)
        {
            store_pre_dire = (char *)calloc(1000, 1);
            store_pre_dire = final_dire;
        }
    }
    return 0;
}