#include "headers.h"

void over_kill(char **argv)
{
    if (strcmp(argv[0], "overkill") != 0)
    {
        return;
    }
    f_f = 1;
    for (int i = 0; i < jobs; i++)
    {
        int pid = job_sequence[i].pid;
        int l = kill(pid, SIGKILL);
        if (l < 0)
        {
            perror("ERROR\n");
        }
    }
}