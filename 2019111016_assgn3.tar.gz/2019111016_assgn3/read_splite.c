#include "headers.h"

void get_name()
{
    char *hostname, *username;
    hostname = (char *)malloc(100 * sizeof(char));
    username = (char *)malloc(100 * sizeof(char));
    gethostname(hostname, 100);
    getlogin_r(username, 100);
    printf("%s@%s:", username, hostname);
}
char *read1()
{
    char *command = NULL;
    ssize_t n = 0;
    ssize_t value = getline(&command, &n, stdin);
    return command;
}
void break_command(char *argv)
{
    char **str = (char **)malloc(max_command * (sizeof(char *)));
    if (!str)
    {
        fprintf(stderr, "Memory allocation error\n");
        exit(0);
    }
    int count = 0;

    char *token;
    token = strtok(argv, " \n");
    while (token != NULL)
    {
        str[count++] = token;
        //printf("%s ", token);
        token = strtok(NULL, " \n");
    }
    for (int i = count; i < count + 2; i++)
        str[i] = NULL;
    struc.str = str;
    struc.temp = count;
    // return {struc.temp, struc.str};
}