#include "headers.h"

void done(int pid, char *pass) // checking for "done" & "abnormal"
{
    //  int i=0;
    int i = 0;
    for (i = 0; i < jobs; i++)
    {
        if (job_sequence[i].pid == pid)
        {
            job_sequence[i].sta = pass;
            job_sequence[i].f = 0;
            break;
        }
    }
    // for (int j = i + 1; j < jobs; j++)
    // {
    //     strcpy(job_sequence[j - 1].path, job_sequence[j].path);
    //     job_sequence[j - 1].pid = job_sequence[j].pid;
    //     job_sequence[j - 1].f = job_sequence[j].f;
    //     strcpy(job_sequence[j - 1].sta, job_sequence[j].sta);
    // }
    // jobs--;
}

void remove1() // removing "done" and "abnormal"
{
    int i = 0;
    int count = 0;
    // printf("%d\n", jobs);
    for (int i = 0; i < jobs; i++)
    {
        if (job_sequence[i].sta == NULL)
        {
            job_sequence[count].pid = job_sequence[i].pid;
            //  strcpy(job_sequence[count].sta, job_sequence[i].sta);
            strcpy(job_sequence[count].path, job_sequence[i].path);
            count++;
            continue;
        }
        if (strcmp(job_sequence[i].sta, "done") == 0 || strcmp(job_sequence[i].sta, "abnormal") == 0)
            continue;
        else
        {
            // printf("%d %d\n", i, count);
            job_sequence[count].pid = job_sequence[i].pid;
            strcpy(job_sequence[count].sta, job_sequence[i].sta);
            strcpy(job_sequence[count].path, job_sequence[i].path);
            count++;
        }
    }
    jobs = count;
}

void kjob(char **argv)
{
    if (strcmp(argv[0], "kjob") != 0)
    {
        return;
        //  continue;
    }
    f_f = 1;
    int i = 0;
    int length = 0;
    while (argv[i] != NULL)
    {
        i++;
    }
    length = i;
    if (length != 3)
    {
        printf("Error in command line\n");
        return;
    }
    int num = atoi(argv[1]);
    if (num > jobs)
    {
        printf("NO job exist\n");
        return;
    }
    int pid = job_sequence[num - 1].pid;
    int sig_num = atoi(argv[2]);
    kill(pid, sig_num);
}