#include "headers.h"

void fun_io_redirect(char **argv)
{
    char **run_command = (char **)calloc(1000, 1);
    int i = 0;
    while (strcmp(argv[i], "<"))
    {
        run_command[i] = argv[i];
        i++;
    }
    int k = struc.temp - 1;
    while (argv[k] != NULL)
    {

        if (!strcmp(argv[k], ">"))
        {
            run_commands(run_command, argv[i + 1], argv[k + 1], 1, 1);
            argv[i + 1] = NULL;
        }
        else
        {
            if (!strcmp(argv[k], ">>"))
            {
                run_commands(run_command, argv[i + 1], argv[k + 1], 1, 2);
                argv[i + 1] = NULL;
            }
        }
    }
}

void fun_o_redirect(char **argv)
{
    //printf("%d\n", struc.temp);
    int i = 0;
    while (argv[i] != NULL)
    {
        // printf("%s\n", argv[i]);
        i++;
    }
    //printf("%d\n", i);
    char **run_command = (char **)calloc(1000, 1);
    int h = i;
    i = 0;
    while (i < h)
    {
        if (strcmp(argv[i], ">") == 0 || strcmp(argv[i], ">>") == 0)
        {
            break;
        }
        run_command[i] = argv[i];
        i++;
    }
    //printf("%d\n", i);
    int k = h - 1;
    while (k >= 0 && argv[k] != NULL)
    {
        if (!strcmp(argv[k], ">"))
        {
            //printf("avcause\n");
            run_commands(run_command, NULL, argv[k + 1], 0, 1);
        }
        if (!strcmp(argv[k], ">>"))
        {
            // printf("2\n");
            run_commands(run_command, NULL, argv[k + 1], 0, 2);
        }
        k--;
        //("outside %d\n", k);
    }
    // printf("%d", k);
}
void fun_i_redirect(char **argv)
{
    char **run_command = (char **)calloc(1000, 1);
    // int t = 0;
    // while (t < struc.temp)
    // {
    //     printf("%s\n", argv[t]);
    //     t++;
    // }
    int i = 0;
    while (argv[i] != NULL)
    {
        // printf("%s\n", argv[i]);
        i++;
    }
    //p
    int h = i;
    i = 0;

    while (i < h)
    {
        if (strcmp(argv[i], "<") == 0)
        {
            break;
        }
        run_command[i] = argv[i];
        i++;
    }
    // t = 0;
    // while (t < i)
    // {
    //     printf("%s\n", run_command[t]);
    //     t++;
    // }
    //printf("%d\n", i);
    int k = h - 1;
    while (k >= 0 && argv[k] != NULL)
    {
        if (!strcmp(argv[k], "<"))
        {
            // printf("1\n");
            //printf("%s\n", argv[k + 1]);
            run_commands(run_command, argv[k + 1], NULL, 1, 0);
        }
        k--;
        //("outside %d\n", k);
    }
}