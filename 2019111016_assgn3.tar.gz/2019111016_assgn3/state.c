#include "headers.h"

void bg(char **argv)
{
    int i = 0;
    while (argv[i] != NULL)
    {
        i++;
    }
    if (strcmp(argv[0], "bg") != 0)
    {
        return;
    }
    f_f = 1;
    if (i != 2)
    {
        printf("ERROR in Command line\n");
        return;
    }
    int job_num = atoi(argv[1]);

    if (job_num > jobs)
    {
        printf("NO JOBS EXIST\n");
        return;
    }

    kill(job_sequence[job_num - 1].pid, SIGCONT);
}