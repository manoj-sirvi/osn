#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <syscall.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <wait.h>
#include <dirent.h>
#include <time.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <setjmp.h>
#include <signal.h>

int main()
{
    int file_desc = open("tricky.txt", O_WRONLY | O_APPEND | O_CREAT);

    // here the newfd is the file descriptor of stdout (i.e. 1)
    dup2(file_desc, 1);

    // All the printf statements will be written in the file
    // "tricky.txt"
    printf("I will be printed in the file tricky.txt\n");

    return 0;
}