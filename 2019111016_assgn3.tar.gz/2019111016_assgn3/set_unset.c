#include "headers.h"

void set1(char **argv)
{
    if (strcmp(argv[0], "setenv") != 0)
    {
        return;
    }
    f_f = 1;
    int i = 0;
    while (argv[i] != NULL)
    {
        i++;
    }
    int length = i;
    //  printf("%d\n", length);
    i = 0;
    if (length != 2 && length != 3)
    {
        printf("Error in command line");
        return;
    }
    if (length == 2)
    {
        setenv(argv[1], " ", 1);
    }
    else
    {
        setenv(argv[1], argv[2], 1);
    }
}

void unset1(char **argv)
{
    if (strcmp(argv[0], "unsetenv") != 0)
    {
        return;
    }
    f_f = 1;
    int i = 0;
    while (argv[i] != NULL)
    {
        i++;
    }
    int length = i;
    if (length != 2)
    {
        return;
    }
    unsetenv(argv[1]);
}