#include "headers.h"

void print_job(char **argv)
{
    if (strcmp(argv[0], "jobs"))
    {
        return;
    }
    f_f = 1;
    int i = 0;
    //printf("%d\n", jobs);
    for (int i = 0; i < jobs; i++)
    {
        //printf("%d\n", i);
        if (job_sequence[i].sta != NULL)
        {
            // printf("\nyes\n");
            printf("[%d] %s %s [%d]\n", i + 1, job_sequence[i].sta, job_sequence[i].path, job_sequence[i].pid);
            continue;
        }
        // printf("%d\n", job_sequence[i].pid);
        char *stat = (char *)calloc(1000, 1);
        //printf("%d\n", i);
        strcpy(stat, "/proc/");
        // printf("%s\n", stat);
        int pid = job_sequence[i].pid;
        char *p = (char *)calloc(1000, 1);
        sprintf(p, "%d", pid);
        // printf("pid %s\n", p);
        strcat(stat, p);
        // printf("%s\n", stat);
        strcat(stat, "/stat");
        //   printf("%s\n", stat);
        FILE *fd = fopen(stat, "r");
        char *st = (char *)calloc(1000, 1);
        char c;
        int pi;
        int count = 0;
        char ans;
        char *status = (char *)calloc(1000, 1);
        while (c = fgetc(fd))
        {
            if (c == EOF)
            {
                break;
            }
            if (c == ' ' || c == '\n')
            {
                count++;
            }
            if (count == 2)
            {
                ans = c;
            }
        }
        if (ans == 'T')
        {
            status = "stopped";
        }
        else
        {
            status = "running";
        }
       // printf("\n%c\n", ans);
        printf("[%d] %s %s [%d]\n", i + 1, status, job_sequence[i].path, pid);
        fclose(fd);
    }
    //  printf("\nout\n");
    remove1();
}