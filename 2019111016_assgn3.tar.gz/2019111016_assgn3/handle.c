#include "headers.h"

void handler(int sig)
{
    int status;
    //printf("enter");
    int u = waitpid(0, &status, WNOHANG);
    // printf("yes ");
    if (u == -1)
    {
        printf("Error");
    }
    //   printf("exited successfully\n");
    // sprintf(exit, "\nProcess with pid %d exited ", u);
    //  printf("%s ", exit_status);
    if (WIFEXITED(status))
    {
        printf("\nProcess with pid %d exited normally\n", u);
        done(u, "done");
    }
    else if (WIFSIGNALED(status))
    {
        printf("\nprocess ended abnormally\n");

        done(u, "abnormal");
    }
    else if (WIFSTOPPED(status))
    {
        printf("\nProcess stopped\n");
        //   done(u, "stopped");
        // jobs -= 1;
    }
    else
        (EXIT_SUCCESS);
    // for (int i = 0; i < jobs; i++)
    // {
    //     printf("%d\n", job_sequence[i].pid);
    // }
}

void ctrl_c(int p)
{
    if (global_pid < 0)
    {
        return;
    }
    //  printf
    // signal(SIGINT, &sigkill);
    kill(global_pid, SIGKILL);
    // if (p == SIGINT)
    //   sleep(0);

    // fflush(stdout);
}

void ctrl_z(int sig)
{
    // printf("%d %s\n", global_pid, current_fg_name);
    //global_pid = getpid();
    //printf("%d %s\n", global_pid, current_fg_name);
    if (global_pid < 0)
    {
        //  perror("ERROR");
        return;
    }
    //printf("tree\n");
    job_sequence[jobs].path = current_fg_name;
    //printf("tree\n");
    job_sequence[jobs].pid = global_pid;
    // printf("tree\n");
    ++jobs;

    signal(SIGTSTP, &ctrl_z);
    kill(global_pid, SIGSTOP);

    //  fflush(stdout);
}
