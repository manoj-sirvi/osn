#include "headers.h"

void excute_command(char **argv)
{
    int pid = fork();
    current_fg_name = (char *)calloc(1000, 1);
    strcpy(current_fg_name, argv[0]);
    if (pid < 0)
    {
        perror("ERROR");
        return;
    }
    if (pid == 0)
    {
        if (execvp(argv[0], argv) < 0)
        {
            printf("ERROR\n");
        }
        exit(0);
    }
    else
    {
        global_pid = pid;
        czz = 0;
        int status;
        waitpid(pid, &status, WUNTRACED);
    }
}