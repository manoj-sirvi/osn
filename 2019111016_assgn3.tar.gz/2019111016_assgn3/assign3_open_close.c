#include "headers.h"

void run_commands(char **command, char *input_file, char *output_file, int in, int out)
{
    int pid = fork();
    int i = 0;
    // while (command[i] != NULL)
    // {
    //     printf("%s\n", command[i]);
    //     i++;
    // }
    if (pid < 0)
    {
        perror("ERROR:");
    }
    if (pid == 0)
    {

        if (out == 1)
        {
            //
            int fd2 = open(output_file, O_TRUNC | O_WRONLY | O_CREAT, 0644);
            if (fd2 < 0)
            {
                perror("ERROR:");
            }
            dup2(fd2, 1);
            // close(fd1);
            close(fd2);
        }
        if (out == 2)
        {
            //   printf("you\n");
            // printf("%s\n", output_file);
            int fd2 = open(output_file, O_APPEND | O_WRONLY | O_CREAT, 0644);
            //printf("%d\n\n", fd2);
            if (fd2 < 0)
            {
                perror("ERROR:");
            }
            dup2(fd2, 1);
            // close(fd1);
            close(fd2);
            //  printf("me\n");
        }
        if (in)
        {
            int fd1 = open(input_file, O_RDONLY, 0644);
            if (fd1 < 0)
            {
                perror("ERROR:");
            }
            dup2(fd1, 0);
            // close(fd1);
            close(fd1);
        }

        // printf("\n");
        execvp(command[0], command);
        exit(0);
    }
    else
    {
        wait(NULL);
    }
}