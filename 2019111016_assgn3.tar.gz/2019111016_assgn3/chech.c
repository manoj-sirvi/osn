#include "headers.h"
void fun(char **argv)
{
    // printf("enter\n");
    int i = 0, pipe = 0, input = 0, output = 0;
    while (argv[i] != NULL)
    {
        i++;
    }
    int length = i;
    i = 0;
    while (i < length)
    {
        // printf("%s\n", argv[i]);
        if (strcmp(argv[i], "<") == 0)
        {
            main_flag = 1;
            input++;
        }
        if (strcmp(argv[i], ">") == 0 || strcmp(argv[i], ">>") == 0)
        {
            main_flag = 1;
            output++;
        }
        if (strcmp(argv[i], "|") == 0)
        {
            main_flag = 1;
            pipe++;
        }
        i++;
    }
    // printf("tr%d %d %d %dpr\n", output, input, pipe, i);
    if (pipe == 0)
    {
        if (input && output)
        {
            fun_io_redirect(argv);
            f_f = 1;
            //continue;
        }
        if (input && !output)
        {
            // printf("enter\n");
            fun_i_redirect(argv);
            f_f = 1;
            //  continue;
        }
        if (!input && output)
        {
            //printf("enter\n");

            fun_o_redirect(argv);
            f_f = 1;
            // printf("final\n");
            //   continue;
        }
    }
    else
    {
        // printf("enter\n");
        piping(argv);
        f_f = 1;
        //   continue;
        //printf("cout \n");
    }
    if (pipe != 0 && output != 0 && input != 0)
    {
        f_f = 1;
    }
}

void again(char **command, int length)
{
    int i = 0;
    //int len = strlen(command);
    // //int i = 0;
    // for (int i = 0; i < length; i++)
    // {
    //     printf("%s\n", command[i]);
    //     i++;
    // }
    i = 0;
    int in = 0;
    int out = 0;
    for (int i = 0; i < length; i++)
    {
        if (!strcmp(command[i], "<"))
        {
            in++;
        }
        if (!strcmp(command[i], ">") || !strcmp(command[i], ">>"))
        {
            out++;
        }
    }
    //  printf("%d %d\n", out, in);
    if (in && out)
    {
        fun_io_redirect(command);
    }
    else if (in && !out)
    {
        fun_i_redirect(command);
    }
    else if (!in && out)
    {
        fun_o_redirect(command);
    }
    else
    {
        //   printf("enter\n");
        // int j = 0;
        // while (command[i] != NULL)
        // {
        //     printf("%s\n", command[i]);
        //     i++;
        // }
        run_commands(command, NULL, NULL, 0, 0);
    }
}