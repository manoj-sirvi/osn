#include "headers.h"

void piping(char **argv)
{
    char *arr[1000][1000];
    int i = 0;
    int k = 0;
    int j = 0;
    int a[1000] = {0};
    // printf("starting\n");
    while (argv[i] != NULL)
    {
        //printf("ans1%s\n", argv[i]);
        if (strcmp(argv[i], "|") == 0)
        {
            a[k] = j;
            arr[k][j] = NULL;
            k++;
            j = 0;
            i++;
            continue;
        }
        else
        {
            arr[k][j] = argv[i];
            j++;
        }
        i++;
    }
    a[k] = j;
    arr[k][j] = NULL;
    int len = k;

    // char *PIPE = "|"; //*cmd = strtok(commands, PIPE);
    int cmdIndex = 0;
    int *oddPipe = (int *)calloc(sizeof(int) * 2, 1);
    int *evenPipe = (int *)calloc(sizeof(int) * 2, 1);
    int **pipes = (int **)calloc(sizeof(int *) * 2, 1);
    int noOfCommands = k + 1;
    pipes[0] = evenPipe;
    pipes[1] = oddPipe;
    int parity;

    while (cmdIndex < k + 1)
    {

        parity = cmdIndex % 2;
        if (pipe(pipes[parity]) < 0)
        {
            perror("Piping Error");
            return;
        }

        pid_t pid = fork();

        if (pid < 0)
        {
            perror("ERROR IN FORK");
            return;
        }
        if (pid == 0)
        {

            if (cmdIndex == 0)
            {
                dup2(pipes[0][1], 1);
            }
            else if (cmdIndex == k)
            {
                dup2(pipes[!parity][0], 0);
            }
            else
            {
                dup2(pipes[parity][1], 1);
                dup2(pipes[!parity][0], 0);
            }
            again(arr[cmdIndex], a[cmdIndex]);
            exit(0);
        }
        else
        {
            wait(NULL);
            if (cmdIndex == 0)
            {
                close(pipes[0][1]);
            }
            else if (cmdIndex == k)
            {
                int t = !parity;
                close(pipes[t][0]);
            }
            else
            {
                close(pipes[parity][1]);
                close(pipes[!parity][0]);
            }
            cmdIndex++;
        }
    }
}