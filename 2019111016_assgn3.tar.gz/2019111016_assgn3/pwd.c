#include "headers.h"

void get_pwd(char **argv)
{

    char *path = (char *)malloc(1000);
    getcwd(path, 1000);
    char g[] = "pwd";
    int f = 0;
    for (int i = 0; i < strlen(argv[0]); i++)
    {
        if (g[i] != argv[0][i])
            f = 1;
    }
    if (f)
        return;
    else
    {
        f_f=1;
        if (path == NULL)
        {
            printf("Error\n");
        }
        else
        {
            printf("%s\n", path);
        }
    }
}