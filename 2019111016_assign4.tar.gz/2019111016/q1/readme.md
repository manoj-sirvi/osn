how to run-:
(i) gcc q1.c 
(ii) ./a.out

# explaination

(i). normal merge function has been implemented who merge two sorted arr in one array;
(ii). for concurrancy merge sort we create two child one for left and one for right
(iii) use shmget() for share memory allocation and shmat() for shared memory operation.


# note-:
normal merge sort is faster than concurrent merge sort on normal machine. 
