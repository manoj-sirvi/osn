#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <wait.h>
#include <time.h>

void insertionSort(int arr[], int n);
void merge(int a[], int l1, int h1, int h2);

void mergeSort(int a[], int l, int h)
{
    int i, len = (h - l + 1);

    // Using insertion sort for small sized array
    if (len <= 5)
    {
        insertionSort(a + l, len);
        return;
    }

    pid_t lpid, rpid;
    lpid = fork();
    if (lpid < 0)
    {
        // Lchild proc not created
        perror("Left Child Proc. not created\n");
        _exit(-1);
    }
    else if (lpid == 0)
    {
        mergeSort(a, l, l + len / 2 - 1);
        _exit(0);
    }
    else
    {
        rpid = fork();
        if (rpid < 0)
        {
            // Rchild proc not created
            perror("Right Child Proc. not created\n");
            _exit(-1);
        }
        else if (rpid == 0)
        {
            mergeSort(a, l + len / 2, h);
            _exit(0);
        }
    }

    int status;

    // Wait for child processes to finish
    waitpid(lpid, &status, 0);
    waitpid(rpid, &status, 0);

    // Merge the sorted subarrays
    merge(a, l, l + len / 2 - 1, h);
}

void insertionSort(int arr[], int n)
{
    int i, key, j;
    for (i = 1; i < n; i++)
    {
        key = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

void mergesort(int arr[], int l, int h)
{
    int a = h - l + 1;
    if (h - l <= 1)
    {
        return;
    }
    mergesort(arr, l, l + a / 2 - 1);
    mergesort(arr, l + a / 2, h);
    merge(arr, l, l + a / 2 - 1, h);
}
void merge(int a[], int l1, int h1, int h2)
{

    int count = h2 - l1 + 1;
    int sorted[count];
    int i = l1, k = h1 + 1, m = 0;
    while (i <= h1 && k <= h2)
    {
        if (a[i] < a[k])
            sorted[m++] = a[i++];
        else if (a[k] < a[i])
            sorted[m++] = a[k++];
        else if (a[i] == a[k])
        {
            sorted[m++] = a[i++];
            sorted[m++] = a[k++];
        }
    }

    while (i <= h1)
        sorted[m++] = a[i++];

    while (k <= h2)
        sorted[m++] = a[k++];

    int arr_count = l1;
    for (i = 0; i < count; i++, l1++)
        a[l1] = sorted[i];
}

int main()
{
    //printf("hello\n");
    int shmid;
    key_t key = IPC_PRIVATE;
    int *shm_array; //*arr;

    int length;
    scanf("%d", &length);
    int arr[length];
    size_t SHM_SIZE = sizeof(int) * length;

    //rgesort(arr, 0, length - 1);
    // Create the segment.
    if ((shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666)) < 0)
    {
        perror("shmget");
        _exit(1);
    }

    // Now we attach the segment to our data space.
    if ((shm_array = shmat(shmid, NULL, 0)) == (int *)-1)
    {
        perror("shmat");
        _exit(1);
    }
    for (int i = 0; i < length; i++)
    {
        scanf("%d", &arr[i]);
        // arr[i] = shm_array[i];
        shm_array[i] = arr[i];
    }
    printf("normal merge sort\n");
    clockid_t begin = clock();
    mergesort(arr, 0, length - 1);
    clockid_t end = clock();
    double time = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("%lf\n", time);

    for (int i = 0; i < length; i++)
    {
        printf("%d ", arr[i]);
    }
    // me
    // Create a random array of given length
    // srand(time(NULL));
    //fillData(shm_array, length);

    // Sort the created array
    printf("\n");
    printf("child merge sort\n");
    clockid_t begin1 = clock();
    mergeSort(shm_array, 0, length - 1);
    clockid_t end1 = clock();
    double time1 = (double)(end1 - begin1) / CLOCKS_PER_SEC;
    printf("%lf\n", time1);

    for (int i = 0; i < length; i++)
    {
        printf("%d ", shm_array[i]);
    }

    return 0;
}
