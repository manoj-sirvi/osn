#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
//int num = (rand() %
//         (upper - lower + 1)) + lower;
pthread_cond_t cond;
pthread_mutex_t mutex;
typedef struct vaccination
{
    int id;
    int batch;
    int capacity;
    int slots;
    int occupancy;
    float prob;
    pthread_cond_t vac_cond;
    pthread_mutex_t vac_mutex;
    pthread_t vac_thread_id;

} vaccination;
typedef struct student
{
    int number;
    pthread_t student_id;
    int round;
    int vac_id;
    pthread_mutex_t student_mutex;
    pthread_cond_t student_cond;
} student;
typedef struct pharma
{
    int id;
    int batch_left;
    int capacity;
    float probability;
    pthread_t phar_thread_id;
    pthread_mutex_t pharma_mutex;
    pthread_cond_t phrama_cond;

} pharma;

typedef struct storer
{
    /* data */
    student a;
} storer;

int n, m, o;
pharma pharmas[1000];
vaccination vacc[1000];
student stud[1000];
int waiting_students = 10;
storer arr[1000];
int min(int a, int b, int c)
{
    if (a <= b && a <= c)
        return a;
    if (b <= a && b <= c)
        return b;
    if (c <= a && c <= b)
        return c;
    return 0;
}
void *phar_thread(void *args);
void *distribute(pharma *args);
void *vaccinzed(void *args);
void wait_for_zone(int id);
void *student_arrive(void *args);
void antibody(vaccination *args);
void *vaccina_pharma(void *args);
void remove1(int id, int k);
void *slot_allocation(vaccination *args);
void *student_thread(void *args);

void *check_batch(pharma *args)
{
    printf("Pharmaceutical Company %d has prepared %d batches of vaccines which have success probability %f.Waiting for all the vaccines to be used to resume production\n\n", args->id + 1, args->batch_left, args->probability);
    while (1)
    {
        // printf("danger\n");
        if (args->batch_left == 0)
        {
            //printf("hiii\n");
            printf("All the vaccines prepared by Pharmaceutical Company %d are emptied. Resuming production now.\n\n", args->id + 1);
            pthread_mutex_unlock(&args->pharma_mutex);
            phar_thread(args);
            //  printf("kill\n");

            break;
        }
        else
        {
            //printf("hedrt\n");
            // args->batch_left = 0;
            pthread_cond_wait(&args->phrama_cond, &args->pharma_mutex);
        }
    }

    // pthread_mutex_unlock(&args->pharma_mutex);
    return NULL;
}

void *phar_thread(void *args)
{
    pharma *ty = (pharma *)args;
    while (1)
    {
        int a = rand() % 4 + 2;

        pthread_mutex_lock(&ty->pharma_mutex);
        int bat = rand() % 5 + 1;
        //  printf("%d\n", bat);
        ty->batch_left = bat;
        sleep(2);
        ty->capacity = rand() % 11 + 10;
        //  ty->probability = (float)rand() / (RAND_MAX * 1.0);
        printf("Pharmaceutical Company %d is preparing %d batches of vaccines which have success probability %f where %d is the number of batches the Pharmaceutical Company is preparing for that particular round where %f is the probability of that vaccine successfully administrating antibodies\n\n\n", ty->id + 1, ty->batch_left, ty->probability, ty->batch_left, ty->probability);
        //  printf("thread_id prepare batches\n");
        sleep(a);
        //  printf("hello\n");
        check_batch(ty);
    }
    return NULL;
}

void *vaccination_thread(void *args)
{
    vaccination *ty = (vaccination *)args;
    int flag = 0;
    while (flag == 0)
    {
        // printf("time\n");
        for (int i = 0; i < n; i++)
        { /* code */
            // printf("entry\n");
            if (ty->capacity != 0)
            {
                //  pthread_mutex_unlock(&pharmas[i].pharma_mutex);
                break;
            }
            printf("Vaccination Zone %d has run out of vaccines\n", ty->id + 1);
            pthread_mutex_lock(&pharmas[i].pharma_mutex);
            // if (ty->capacity != 0)
            // {
            //   //  pthread_mutex_unlock(&pharmas[i].pharma_mutex);
            //     break;
            // }
            //  printf("valuue %d\n", pharmas[i].batch_left);
            if (pharmas[i].batch_left)
            {
                ty->capacity = pharmas[i].capacity;
                pharmas[i].batch_left -= 1;
                ty->prob = pharmas[i].probability;
                // printf("\n%d %d\n", ty->id, ty->capacity);

                printf("Pharmaceutical Company %d has delivered vaccines to Vaccination zone %d, resuming vaccinations now\n\n", pharmas[i].id + 1, ty->id + 1);
            }
            // printf("valuue1 %d\n", pharmas[i].batch_left);
            if (pharmas[i].batch_left == 0)
            {
                pthread_cond_signal(&pharmas[i].phrama_cond);
                pthread_mutex_unlock(&pharmas[i].pharma_mutex);
                // flag = 1;
                break;
            }
            else
            {
                pthread_mutex_unlock(&pharmas[i].pharma_mutex);
                // flag = 1;
                break;
            }
        }
        // printf("calling\n");
        if (ty->slots == 0)
            slot_allocation(ty);
    }
}
void *slot_allocation(vaccination *args)
{
    int flag = 1;
    // sleep(5);
    while (flag)
    {

        // if (waiting_students <= 0)
        // {
        //     exit(0);
        // }
        // printf("\n stru = %d %d\n", args->capacity, waiting_students);
        if (args->capacity > 0 && waiting_students > 0)
        {
            printf("vaccination zone %d has been assigned slots\n", args->id + 1);
            int min_value = min(8, waiting_students, args->capacity);
            //  printf("%d\n", min_value);
            if (min_value == 0)
            {
                printf("simulation over\n");
                exit(0);
            }
            int random = rand() % min_value + 1;
            args->slots = random;
            args->occupancy = random;
            flag = 0;
        }
        flag = 0;
    }
}
void waiting(int v)
{

    int count = 0;
    for (int i = 0; i < o; i++)
    {
        if (stud[i].vac_id == v)
        {
            float yu = (float)rand() / (RAND_MAX * 1.0);
            // printf("ghiih\n\n");
            //printf("\n\n%f %f\n\n", vacc[v].prob, yu);
            printf("Student %d on Vaccination Zone %d has been vaccinated which has success probability %f Where %f is the probability ​ of that vaccine successfully administrating antibodies\n\n", i + 1, v + 1, yu, yu);
            if (vacc[v].prob - yu < 0.0)
            {
                stud[i].round++;
                stud[i].vac_id = -1;
                arr[count++].a = stud[i];
                printf("student %d tested positive for antibodies\n\n", i + 1);
                // student_thread(&stud[i]);
            }
            else
            {
                printf("student %d tested negative for antibodies\n\n", i + 1);
                waiting_students--;
            }
        }
    }
    //    printf("gtuyuy\n");
    // void *yu = (void *)&arr[0].a;
    // student *op = (student *)yu;
    // printf("%d %d %d\n\n", op->number, op->round, op->vac_id);
    for (int i = 0; i < count; i++)
    {
        //  printf("\nrecalling for %d\n\n", arr[i].a.number + 1);
        student_thread((void *)&arr[i].a);
        //printf("complte\n");
        pthread_cond_wait(&arr[i].a.student_cond, &arr[i].a.student_mutex);
    }
    //  pthread_cond_signal(&vacc[v].vac_cond);
}
void slot_filling(student *args)
{
    int flag = 1;
    while (flag)
    {
        for (int i = 0; i < m; i++)
        {

            //printf("hii=%d\n", args->round);
            pthread_mutex_lock(&vacc[i].vac_mutex);
            printf("Vaccination Zone %d is ready to vaccinate with %d slots ​ where %d is the number of slots available inthat zone for that particular round of vaccination.\n\n", i + 1, vacc[i].slots, vacc[i].slots);
            // printf("id = %d\n", vacc[i].id);
            if (vacc[i].slots == 0)
            {
                // printf("slot refilling\n");
                slot_allocation(&vacc[i]);
                break;
            }
          //  printf("slots=%d\n", vacc[i].slots);
            if (vacc[i].slots)
            {
                vacc[i].slots--;
                args->vac_id = i;
                pthread_cond_signal(&args->student_cond);
                printf("Student %d assigned a slot on the Vaccination Zone %d and waiting to be vaccinated\n\n", args->number + 1, i + 1);
                // printf("student got slot\n");
            }
            //  printf("checker slots =  %d", vacc[i].slots);
            if (vacc[i].slots == 0)
            {
                // printf("slot refilling\n");
                slot_allocation(&vacc[i]);
            }
            // printf("%d\n", vacc[i].slots);
            // printf("refilling complted\n\n");
            // printf("reslots=%d\n", vacc[i].slots);
            //  pthread_mutex_unlock(&vacc[i].vac_mutex);
            pthread_mutex_unlock(&vacc[i].vac_mutex);
            // pthread_cond_wait(&vacc[i].vac_cond, &vacc[i].vac_mutex);
            printf("Vaccination Zone %d entering Vaccination Phase\n", i + 1);
            waiting(i);
            sleep(3);

            // printf("outside\n\n");
            // sleep(3);
            //  }

            // flag = 0;
            //  pthread_mutex_unlock(&vacc[i].vac_mutex);
        }
        if (waiting_students <= 0)
        {
            // printf("ws=%d\n", waiting_students);
            sleep(10);
            printf("Simulation over\n");
            exit(0);
        }
        flag = 0;
        //  break;
        // ;
    }
}
void *student_thread(void *args)
{
    student *ty = (student *)args;
    printf("Student %d has arrived for his %d round of Vaccination\n\n", ty->number + 1, ty->round);
    // if (waiting_students <= 0)
    // {
    //     printf("Simulation over\n");
    //     exit(-1);
    // }

    int random_data = rand() % 3 + 1;
    sleep(random_data);
    //   printf("student allocation %d\n", ty->round);
    printf("Student %d is waiting to be allocated a slot on a Vaccination Zone\n\n", ty->number + 1);
    slot_filling(ty);
}

int main()
{
    ///  pthread_cond_init(&cond, 0);
    //pthread_mutex_init(&mutex, 0);

    scanf("%d%d%d", &n, &m, &o);
    float pro[n];
    for (int i = 0; i < n; i++)
    {
        scanf("%f", &pro[i]);
    }
    int pos[n];
    waiting_students = o;
    for (int i = 0; i < n; i++)
    {
        pos[i] = 1;
    }
    for (int i = 0; i < n; i++)
    {
        pharmas[i].probability = pro[i];
        pharmas[i].id = i;
        pthread_mutex_init(&pharmas[i].pharma_mutex, 0);
    }
    for (int i = 0; i < m; i++)
    {
        vacc[i].id = i;
        vacc[i].slots = 0;
        pthread_mutex_init(&vacc[i].vac_mutex, 0);
    }
    for (int i = 0; i < o; i++)
    {
        stud[i].number = i;
        stud[i].round = 1;
        stud[i].vac_id = -1;
        pthread_mutex_init(&stud[i].student_mutex, 0);
    }
    // printf("hello\n");
    for (int i = 0; i < n; i++)
    {
        pthread_create(&pharmas[i].phar_thread_id, NULL, phar_thread, &pharmas[i]);
    }
    sleep(8);

    // // printf("good\n");
    // printf("good\n");
    for (int i = 0; i < m; i++)
    {
        pthread_create(&vacc[i].vac_thread_id, NULL, vaccination_thread, &vacc[i]);
    }
    // //printf("tefg\n");
    sleep(10);
    //  printf("good luck\n");
    for (int i = 0; i < o; i++)
    {
        // printf("hii\n");
        pthread_create(&stud[i].student_id, NULL, student_thread, &stud[i]);
    }
    sleep(20);
    // for (int i = 0; i < n; i++)
    // {
    //     pthread_join(pharmas[i].phar_thread_id, NULL);
    // }
    // for (int i = 0; i < m; i++)
    // {
    //     pthread_join(vacc[i].vac_thread_id, NULL);
    // }
    // for (int i = 0; i < o; i++)
    // {
    //     pthread_join(stud[i].student_id, NULL);
    // }

    for (int i = 0; i < n; i++)
    {
        pthread_mutex_destroy(&pharmas[i].pharma_mutex);
    }
    for (int i = 0; i < m; i++)
    {
        pthread_mutex_destroy(&vacc[i].vac_mutex);
    }
    printf("Simulation over\n");
    return 0;
}
