# run code
(i) gcc q2.c -lpthread
(ii) ./a.out

# implementation
(i) void *phar_thread(void *args);
 create the pharmaceutical thread that will create all values for it.

(ii)void *check_batch(pharma *args);
  checking for batch stock in comapny

(iii) void *vaccination_thread(void *args);
 checking for vaccinization have vaccine or not

(iv)  void slot_allocation(int id);
 distrubitng the medicine and and make slots

 (v)void *student_arrive(void *args);
 make student thread

 (vi) void waitng (vaccination *args);
 testing for antibody

 (vii) slot_filling(student *args):
 assign slot and zone to students


 # logic

 for pharmaceutical companies create n thread which are used busy waiting until all batches are not finfished.

 for vaccination zone distribute them vaccine and create slots for student using 'rand()' function

 for student create o thread then check it for slot using mutex lock on zone if slot is avaialable it will take palce then call the function which is chekced for antibody test for randomized probability.

 if slots are unfill then fill using function slot_allocation 
