# run the code
gcc q3.c -lpthread
./a.out


# functions
void *stage_thread(void *args)
assigned stage for singer and musician


void *cordi(void *args)
given the tshirt to musician

variable sema used for semaphore 
sturct used for store data of musicain , stages, singers etc.

# logic
create k thread for artist who they are performing and call function stage_thread which one assigned the stage to this artist among acourist and electric stages using mutex locks.

sleep the stages for artist going to performe.

create another function who take care of distributing tshirts.

used semaphore for critical sections aur collectiong tshirt and finsihed his performance.

