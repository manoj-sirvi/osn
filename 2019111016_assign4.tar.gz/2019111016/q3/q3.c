#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#define KNRM "\x1B[1;0m"
#define KRED "\x1B[1;31m"
#define KGRN "\x1B[1;32m"
#define KYEL "\x1B[1;33m"
#define KBLU "\x1B[1;34m"
#define KMAG "\x1B[1;35m"
#define KCYN "\x1B[1;36m"
#define KWHT "\x1B[1;37m"
#define KGR "\x1B[1;32m"
sem_t sema;
pthread_mutex_t mutex;
int k, a, e, c, t1, t2, t;
clock_t begin;
typedef struct q
{
    int id;
    int type;
    int assign_time;
    int leaving_time;
    int musi_id;
    pthread_mutex_t stage1_mutex;
    pthread_t thread_id;

} stage1;
typedef struct q3
{
    int id;
    int type;
    int assign_time;
    int leaving_time;
    int musi_id;
    pthread_mutex_t stage2_mutex;
    pthread_t thread_id;

} stage2;

typedef struct q2
{
    int id;
    int type;
    char *name;
    char inst_type;
    int time;
    int stage1;
    int stage2;
    int stage_id;
    int fer_time;
    int get_tshirt;
    int type1;
    int stg2;
    pthread_mutex_t musician_mutex;
    pthread_t thread_id;
    sem_t tshirt;

    /* data */
} musician;

typedef struct q1
{
    /* data */
    int busy;
    pthread_mutex_t cordinator_mutex;
    pthread_t thread_id;
    int value;

} cordinator;
musician ans[1000];
stage1 acou[1000];
stage2 elec[1000];
int interval = 0;
cordinator cor[1000];

void *stage_thread(void *args)
{

    musician *ty = (musician *)args;
    printf("%s%s %c arrived\n", KCYN, ty->name, ty->inst_type);
    int gotten = 1;
    int index;
    //  printf("%d\n", ans[ty->id].time);
    //sleep(ans[ty->id].time);
    int checker = 0;
    //printf("outer\n");
    int hello = 0;
    //  clock_t t = clock();
    while (gotten)
    {
        int flag = 0;
        clock_t time_taken = clock();
        // printf("%ld\n", time_taken);
        double timees = ((double)time_taken) / CLOCKS_PER_SEC;
        //printf("%lf %d\n", timees, t);
        if (timees > ((double)t))
        {
            checker = 1;
            break;
        }

        if (ty->stage1 && ty->stage2 && ty->type1)
        {
            flag = 1;
            hello = 1;
        }
        // printf("flag=%d\n", flag);
        for (int i = 0; i < a; i++)
        {
            if (ty->stage1 == 0)
            {
                break;
            }
            if (flag == 0)
            {
                pthread_mutex_lock(&acou[i].stage1_mutex);
                if (acou[i].type == 0 && ty->stage_id == -1)
                {
                    acou[i].type = 1;
                    gotten = 0;
                    ty->stage_id = i;
                    ty->stg2 = i;
                    ty->type = 1;
                    acou[i].assign_time = clock();
                    acou[i].musi_id = ty->id;
                    acou[i].leaving_time = rand() % (t2 - t1 + 1) + t1;
                    printf("%s%s performing %c at acoustic stage for %d sec\n\n", KBLU, ty->name, ty->inst_type, acou[i].leaving_time);
                    ty->fer_time = acou[i].leaving_time;
                    //printf("a");
                    index = i;
                    pthread_mutex_unlock(&acou[i].stage1_mutex);
                    break;
                }
                pthread_mutex_unlock(&acou[i].stage1_mutex);
            }
            else
            {
                pthread_mutex_lock(&acou[i].stage1_mutex);
                if (acou[i].type == 0)
                {
                    acou[i].type = 1;
                    gotten = 0;
                    ty->type = 1;
                    ty->stg2 = i;
                    acou[i].musi_id = ty->id;
                    //  printf("getting a stage");
                    ty->stage_id = i;
                    acou[i].leaving_time = rand() % (t2 - t1 + 1) + t1;
                    ty->fer_time = acou[i].leaving_time;
                    printf("%s%s performing %c at acoustic stage for %d sec\n\n", KBLU, ty->name, ty->inst_type, acou[i].leaving_time);
                    index = i;
                    pthread_mutex_unlock(&acou[i].stage1_mutex);
                    break;
                }
                else
                {
                    acou[i].leaving_time = 2 + (rand() % (t2 - t1 + 1) + t1);
                    ty->fer_time = acou[i].leaving_time;
                    index = i;
                    ty->stage_id = i;
                    //  printf("getting a stage");
                    printf("%s%s joined %s's performance ,performance extended by 2 secs\n\n", KGRN, ty->name, ans[acou[i].musi_id].name);
                    ty->type = 1;
                    gotten = 0;
                }

                pthread_mutex_unlock(&acou[i].stage1_mutex);
            }
        }
        // printf("got = %d\n", gotten);
        for (int i = 0; i < e; i++)
        {

            if (ty->stage2 == 0 || gotten)
            {
                break;
            }
            if (flag == 0)
            {
                pthread_mutex_lock(&elec[i].stage2_mutex);
                if (elec[i].type == 0 && ty->stage_id == -1)
                {
                    elec[i].type = 1;
                    gotten = 0;
                    ty->type = 2;
                    ty->stage_id = i;
                    elec[i].musi_id = ty->id;
                    //   printf("getting a stage");
                    elec[i].leaving_time = rand() % (t2 - t1 + 1) + t1;
                    ty->fer_time = elec[i].leaving_time;
                    printf("%s%s performing %c at electric stage for %d sec\n\n", KBLU, ty->name, ty->inst_type, elec[i].leaving_time);
                    pthread_mutex_unlock(&elec[i].stage2_mutex);
                    break;
                }
                pthread_mutex_unlock(&elec[i].stage2_mutex);
            }
            else
            {
                pthread_mutex_lock(&elec[i].stage2_mutex);
                if (elec[i].type == 0)
                {
                    elec[i].type = 1;
                    gotten = 0;
                    ty->type = 2;
                    //   printf("getting a stage");
                    ty->stage_id = i;
                    elec[i].musi_id = ty->id;
                    elec[i].leaving_time = rand() % (t2 - t1 + 1) + t1;
                    ty->fer_time = elec[i].leaving_time;
                    printf("%s%s performing %c at acoustic stage for %d sec\n\n", KBLU, ty->name, ty->inst_type, acou[i].leaving_time);
                    pthread_mutex_unlock(&elec[i].stage2_mutex);
                    break;
                }
                else
                {
                    elec[i].leaving_time = 2 + (rand() % (t2 - t1 + 1) + t1);
                    ty->fer_time = elec[i].leaving_time;
                    ty->type = 2;
                    ty->stage_id = i;
                    gotten = 0;
                    printf("%s%s joined %s's performance ,performance extended by 2 secs\n\n", KGRN, ty->name, ans[elec[i].musi_id].name);
                    //  printf("getting a stage");
                }

                pthread_mutex_unlock(&elec[i].stage2_mutex);
            }
            index = i;
        }
        //  break;
    }
    if (checker)
    {
        printf("%s%s left without performing\n\n", KNRM, ty->name);
        return NULL;
    }
    //  printf("waiting\n");
    sleep(ty->fer_time);
    //printf("hello=%d  %d\n\n", hello, ty->type);

    ty->get_tshirt = 1;
    if (ty->type == 2)
    {
        printf("%s%s performace  finished\n\n", KWHT, ty->name);
        pthread_mutex_lock(&elec[ty->stage_id].stage2_mutex);
        elec[ty->stage_id].type = 0;
        if (hello == 0)
            sem_post(&sema);
        pthread_mutex_unlock(&elec[ty->stage_id].stage2_mutex);
        // if (hello == 0)
    }
    else
    {

        if (ty->type == 1)
        {
            printf("%s%s performace  finished\n\n", KWHT, ty->name);
            pthread_mutex_lock(&acou[ty->stage_id].stage1_mutex);
            acou[ty->stage_id].type = 0;
            if (hello == 0)
                sem_post(&sema);
            pthread_mutex_unlock(&acou[ty->stage_id].stage1_mutex);
            // if (hello == 0)
            // {
            // int hi;
            // sem_getvalue(&sema, &hi);
            // printf("1=%d\n", hi);

            // sem_getvalue(&sema, &hi);
            // printf("2=%d\n", hi);
            //}
        }
    }
    if (hello == 0)
    {
        sem_wait(&ty->tshirt);
    }
}

void *cordi(void *args)
{
    cordinator *ty = (cordinator *)args;
    while (1)
    {
        int hi;
        sem_getvalue(&sema, &hi);
        // printf("dna=%d\n", hi);
        sleep(2);
        //printf("hello\n");
        sem_wait(&sema);
        sem_getvalue(&sema, &hi);
        // printf("dna1=%d\n", hi);
        // printf("entring\n");
        ty->busy = 1;
        for (int i = 0; i < k; i++)
        {
            // printf("hiii=%d\n", ans[i].type);
            if (ans[i].type1 == 0)
            {

                pthread_mutex_lock(&ans[i].musician_mutex);
                if (ans[i].get_tshirt == 1)
                {
                    ans[i].get_tshirt = -1;
                    printf("%s%s colleccting tshirt\n", KYEL, ans[i].name);
                    ty->value = i;
                    pthread_mutex_unlock(&ans[i].musician_mutex);
                    break;
                }
                pthread_mutex_unlock(&ans[i].musician_mutex);
            }
        }
        if (ty->value >= 0)
        {
            sleep(2);
            sem_post(&ans[ty->value].tshirt);
            ty->value = 0;
            ty->busy = 0;
        }
        // break;
    }
}

int main()
{
    sem_init(&sema, 0, 0);

    scanf("%d%d%d%d%d%d%d", &k, &a, &e, &c, &t1, &t2, &t);
    char **store = (char **)calloc(1000, 1000);
    char *list = (char *)calloc(1000, 1000);
    int arr[k];
    int count = 0;
    for (int i = 0; i < a; i++)
    {
        acou[i].type = 0;
    }
    for (int i = 0; i < e; i++)
    {
        elec[i].type = 0;
    }

    for (int i = 0; i < k; i++)
    {
        char *name = (char *)calloc(1000, 100);
        char inst_name;
        int time;
        scanf("%s %c %d", name, &inst_name, &time);
        // printf("%s\n", name);
        //int y;
        //scanf("%d", &y);
        // int inst_name;
        //  scanf("%c", &inst_name);
        //inst_name = getchar();
        // printf("%c\n", inst_name);
        //   int time;
        // scanf("%d", &time);
        store[count] = name;
        list[count] = inst_name;
        arr[count] = time;

        ans[count].inst_type = inst_name;
        ans[count].name = name;
        //  printf("%s\n\n", ans[i].name);
        ans[count].id = i;
        ans[count].time = time;
        // printf("%d\n", ans[i].time);
        if (inst_name == 's')
        {
            ans[i].type1 = 1;
        }
        else
        {
            ans[i].type1 = 0;
        }
        if (inst_name == 'p' || inst_name == 'g' || inst_name == 's')
        {
            ans[i].stage1 = 1;
            ans[i].stage2 = 1;
        }
        else
        {
            if (inst_name == 'v')
            {
                ans[i].stage1 = 1;
                ans[i].stage2 = 0;
            }
            else
            {
                ans[i].stage1 = 0;
                ans[i].stage2 = 1;
            }
        }
        ans[i].stage_id = -1;
        ans[i].get_tshirt = -1;
        sem_init(&ans[i].tshirt, 0, 0);
        count++;
        //  printf("hellon\n");
        pthread_mutex_init(&ans[i].musician_mutex, NULL);
    }
    //printf("sgcdsj\n");

    for (int i = 0; i < k; i++)
    {
        // pthread_create(&acou[i].thread_id, NULL, stage_thread, &acou[i]);
        // printf("kiyttn");
        //  printf("%s\n", ans[i].name);
        sleep(ans[i].time);
        pthread_create(&ans[i].thread_id, NULL, stage_thread, &ans[i]);
        //printf("gtvjv\n");
    }
    for (int i = 0; i < c; i++)
    {
        pthread_create(&cor[i].thread_id, NULL, cordi, &cor[i]);
    }

    for (int i = 0; i < k; i++)
    {
        // pthread_create(&acou[i].thread_id, NULL, stage_thread, &acou[i]);
        // printf("kiyttn");
        //  pthread_create(&ans[i].thread_id, NULL, stage_thread, &ans[i]);
        pthread_join(ans[i].thread_id, NULL);
        //printf("gtvjv\n");
    }
    // for (int i = 0; i < c; i++)
    // {
    //     // pthread_create(&cor[i].thread_id, NULL, cordi, &cor[i]);
    //     pthread_join(cor[i].thread_id, NULL);
    // }
    //  printf("iwugcsfc\n\n");
    for (int i = 0; i < k; i++)
    {
        //     // pthread_create(&acou[i].thread_id, NULL, stage_thread, &acou[i]);
        //     // printf("kiyttn");
        //     //  pthread_create(&ans[i].thread_id, NULL, stage_thread, &ans[i]);
        //     pthread_join(ans[i].thread_id, NULL);
        //     //printf("gtvjv\n");
        pthread_mutex_destroy(&ans[i].musician_mutex);
    }
    printf("%sFinished\n\n", KRED);
    exit(0);
    // //sleep(7);
    // for (int i = 0; i < e; i++)
    // {
    //     pthread_create(&elec[i].thread_id, NULL, stage_thread, &elec[i]);
    // }
    //  printf("hello\n");
}
