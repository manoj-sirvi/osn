#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
    int a = fork();
    printf(1, "Testing for waitx\n");
    if (a == 0)
    {
        for (int i = 0; i < 1e6; i++)
        {
        }
    }
    else
    {
        int *wtime = (int *)malloc(sizeof(int));
        int *rtime = (int *)malloc(sizeof(int));
        waitx(wtime, rtime);
        printf(1, "wtime = %d; rtime = %d\n", *wtime, *rtime);
    }

    exit();
}