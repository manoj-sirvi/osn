# run
(1) make clean
(2) make qemu-nox SCHEDULER=<DEFAULT,FCFS,PBS,MLFQ>
select one of from ```DEFAULT,FCFS,PBS,MLFQ```

# waitx
this is a sysytem call same as ```wait()``` but also calculate run(rtime) and wait(wtime) time of process.
for testing of waitx i add ```timc.c``` which is run the process using ```exec```
and then call the waitx function whose calculate the value of rtime and wtime.

``checking_time`` function calculate the run time of process called int ```trap.c```

modified files-:
- syscall.h
- syscall.c
- sysproc.c
- def.h
- proc.c
- time.c
- trap.c
- Makefile
- proc.h
- user.h
- usys.S

# scheduling
```DEFAULT```-: it is round robin algorithm and default algorithm

``` FCFS``` -: this algorithms work that first come process will get cpu first
 preemtion is not allowed
  if (min_time == 0)
        min_time = p;
      else
      {
        if (min_time != 0)
          if (min_time->start_time > p->start_time)
            min_time = p;
      }
      remove preemtnenece using  trap.c
this code taking the process with minimun start time.

```PBS```-:
given that each process have default priority 60.

find the minimum proirity process by interating through the process table using nested loops.

for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    {
      if (p->state != RUNNABLE)
        continue;
      if (p)
      {
        high_p = p;
        for (p1 = ptable.proc; p1 < &ptable.proc[NPROC]; p1++)
        {
          if (p1->state != RUNNABLE)
            continue;
          if (high_p->priority > p1->priority)
          {
            if (p1)
              high_p = p1;
          }
        }
      }
// this code find the process with minimum proirity
  ```set_prority```-: it is system call as waitx who set the new_proirity to process using pid.

```preemting```-: this function check for process that any process with lower prority then this enter then we have to switch the process so this function check for this.

```MLFQ```-:
to implement this i make 5 queue whose priority is in ascending order.
i define ```wait_time``` array to check wait time for process in perticular queue.
check for process which is in higher priority queue and run it.
then in ```trap.c``` we check that if process running time is greater then a perticular value then interuppt occur and if process not completed then agian push it into lower queue priority queue.


 for (int i = 0; i < 5; i++)
    {
      for (int j = 0; j <= back_pointer[i]; j++)
      {
        // checcking for runnable process
        p = queue[i][j];
        pop(p, i);
        f = 1;
        break;
      }
      if (f)
      {
        break;
      }
    }
``` this check for process```
     if (p && p->state == RUNNABLE)
      {
        // cprintf("enter_time\n");
        p->curr_ticks = 0;

        if (p->flag)
        {
          p->flag = 0;
          if (p->queue < 4)
            p->queue++;
        }

        push(p, p->queue);

``` this is agian push the process into queue```.
```queue-implementation```-: 
```pop()```-: this function remove a process from perticular queue and rearrange all process into the queue.
```push()```-: this function add a process into a queue if process not exist and increase the size of queue. and reset the curr_ticks to 0 for new queue.

```Aging```-: if process wait for long time in queue then i will remove it from queue and send it to higher priority queue. this is done in  ```checking_time``` function fo # ifdef MLFQ.


- after running the folloeing command on code-:
DEFAULT-: rtime=6, wtime=3924
FCFS-: rtime=4, wtime=3905
PBS-: rtime=6,wtime=2140
MLFQ-: rtime=4,wtime=2102

# ps
- system call who return detail of process who present in pable
- just run a loop over all process and print deatil using struct proc.
- if pid is 0 then continued

```modified files```-:

- syscall.h
- syscall.c
- sysproc.c
- def.h
- proc.c
- time.c
- trap.c
- Makefile
- proc.h
- user.h
- usys.S