#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
#include "fs.h"

int main(int argc, char *argv[])
{
    int priority, pid;
    if (argc < 3)
    {
        printf(2, "invalid format\n");
        exit();
    }
    pid = atoi(argv[2]);
    priority = atoi(argv[1]);
    if (priority < 0 || priority > 100)
    {
        
        printf(1, "invalid priority number\n");
        exit();
    }
    int pid1 = set_priority(priority, pid);
    if (pid1 != -1)
    {
        printf(1, "SUCCESS\n");
    }
    else
    {
        printf(1, "FAILURE\n");
    }

    // set_priority(priority, pid);
    exit();
}