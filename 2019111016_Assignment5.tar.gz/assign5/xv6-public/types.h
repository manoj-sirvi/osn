typedef unsigned int uint;
typedef unsigned short ushort;
typedef unsigned char uchar;
typedef uint pde_t;
#define MAX_COUNT 1000
// struct proc *queue[5][MAX_COUNT]; // five queues
// int empty(int id);                // checking for emplty or non empty
// void push(int id, struct proc *); // push in queue id
// struct proc *pop(int id);         // using for aging also
// int que_full(int id);             // checking for full of queue
// int size[5];                      // contain number  of process in  queue
// int top_pointer[5];               // top pointer of every queue
// int back_pointer[5];
// int q_ticks[5]; // back pointer for every queue
