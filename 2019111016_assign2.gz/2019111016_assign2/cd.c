#include "headers.h"

void change_dir(char **argv)
{
    char g[] = "cd";
    int f = 0;
    for (int i = 0; i < strlen(argv[0]); i++)
    {
        if (argv[0][i] != g[i])
            f = 1;
    }
    if (!f)
    {
        if (argv[1] == NULL || argv[1][0] == '~')
        {
            chdir(dire1);
        }
        else if (chdir(argv[1]) != 0)
        {
            perror("Error");
        }
    }
}