#include "headers.h"

void echo_cal(char **argv)
{

    int k = 0;
    char g[] = "echo";
    for (int i = 0; i < strlen(argv[0]); i++)
    {

        if (g[i] != argv[0][i])
        {
            k = 1;
            break;
        }
    }
    if (k)
        return;
    if (argv[1][0] == '$')
    {
        // printf("enter\n");
        char *tr = (char *)malloc(1000);
        for (int i = 1; i < strlen(argv[1]); i++)
        {
            tr[i - 1] = argv[1][i];
        }
        tr[strlen(argv[1])] = '\0';
        //  printf("%s\n", tr);
        //  tr[strlen[argv]]
        if (getenv(tr) == NULL)
        {
            for (int i = 2; i < strlen(argv[1]); i++)
            {
                printf("%c", argv[1][i]);
            }
        }
        else
        {
            printf("%s", getenv(tr));
        }
    }
    else
    {
        for (int i = 1; i < 1000 && argv[i] != NULL; i++)
        {
            printf("%s ", argv[i]);
        }
    }
    printf("\n");
}