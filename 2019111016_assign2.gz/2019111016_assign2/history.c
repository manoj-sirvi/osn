#include "headers.h"

int get_history()
{
    //  int fd = open(path_of_history, O_WRONLY);
    int count = 0;
    FILE *fd1 = fopen(path_of_history, "r+");
    char c[1];
    for (int i = 0; i < 25; i++)
    {
        strcpy(hist[i], "\0");
    }
    while (c[0] = fgetc(fd1))
    {
        if (c[0] == EOF)
            break;
        //   printf("%c", c[0]);

        strcat(hist[count], c);
        if (c[0] == '\n')
        {
            count++;
            //  strcpy(hist[count], "\0");
            //  continue;
        }
    }
    //  printf("%d\n\n", count);
    fclose(fd1);
    return count;
}
void store_history(char *line)
{
    int count = get_history();
    count++;
    FILE *fd = fopen(path_of_history, "w");

    //  printf("%d\n", count);
    if (count == 21)
    {
        for (int i = 0; i < 19; i++)
            strcpy(hist[i], hist[i + 1]);
        count--;
    }
    strcpy(hist[count - 1], line);
    int fd1 = fileno(fd);
    lseek(fd1, 0, SEEK_SET);
    for (int i = 0; i < count; i++)
    {
        write(fd1, hist[i], strlen(hist[i]));
        lseek(fd1, 0, SEEK_END);
        // printf("%s\n", hist[i]);
    }
    close(fd1);
    fclose(fd);
}
int count_line()
{
    FILE *fd = fopen(path_of_history, "r");
    int count = 0;
    char c;
    while (c = fgetc(fd))
    {
        if (c == EOF)
            break;

        if (c == '\n')
            count++;
    }
    fclose(fd);
    return count;
}
void print_history(int value)
{
    FILE *fd = fopen(path_of_history, "r");
    int count = 0;
    char c;
    while (c = fgetc(fd))
    {
        if (c == EOF)
            break;
        if (c == '\n')
            count++;
    }
    fseek(fd, 0, SEEK_SET);
    if (!value)
    {
        while (c = fgetc(fd))
        {
            if (c == EOF)
                break;
            printf("%c", c);
        }
    }
    else
    {
        int t = count - value;
        count = 0;
        while (c = fgetc(fd))
        {
            if (c == EOF)
                break;
            if (count >= t)
                printf("%c", c);
            if (c == '\n')
                count++;
        }
    }
    fclose(fd);
}