#include "headers.h"

int main()
{
    int status = 1;
    //char *dire1 = (char *)malloc(1000);
    dire1 = get_shell_dire(); //shell present directory
    path_of_history = get_shell_dire();
    strcat(path_of_history, "/histor.txt");
    //printf("%s\n", path);
    total_store_history = 0;
    // for (int i = 0; i < 25; i++)
    //   strcpy(hist[i], "\0");
    // printf("%s", dire1);
    while (status)
    {

        get_name();
        char *cwd = (char *)malloc(1000);
        getcwd(cwd, 1000);

        char *final_dire = check1(dire1, cwd); //current working directory

        printf("%s$ ", final_dire);
        //   printf("ans");
        // printf("%s %s\n", dire1, cwd);
        char *line = read1();
        store_history(line);
        break_command(line);

        // printf("%s\n ", cwd);
        char **argv = struc.str;
        // int i = 0;
        // while (argv[i] != NULL)
        // {
        //     //printf("%s\n", argv[i]);
        //     i++;
        // }
        int value = struc.temp;
        // printf("%d", struc.temp);
        int flag = 0;
        //  printf("sdjcgsd");

        if (argv[value - 1][0] == '&')
        {
            flag = 1;
            argv[value - 1] = NULL;
        }
        if (!strcmp(argv[0], "history"))
        {
            int p;
            if (argv[1] != NULL)
            {
                p = atoi(argv[1]);
            }
            else
            {
                p = 0;
            }
            //   printf("%d %d\n", p, total_store_history);
            print_history(p);
        }
        if (!flag)
        {
            change_dir(argv);
            // printf("dyusgc");
            echo_cal(argv);
            get_pwd(argv);

            int arr[10] = {0}; // arr[0]=NULL ,arr[1]="-l",arr[2]="-a",arr[3]="(-al)(-la)(-a -l)";
                               //  printf("cdcdcdc\n");
            if (strcmp(argv[0], "ls") == 0)
            {
                char *step = (char *)calloc(1000, 1);
                int i = 1;
                while (argv[i] != NULL)
                {

                    if (strcmp(argv[i], "-l") == 0 || strcmp(argv[i], "-a") == 0 || !(strcmp(argv[i], "-al") || !(strcmp(argv[i], "-la"))))
                    {
                        i++;
                        continue;
                    }
                    strcat(step, argv[i]);
                    i++;
                }
                // printf("a%sb\n", step);
                i = 1;
                if (strlen(step) == 0)
                {
                    // printf("enter");
                    step = ".";
                }
                while (argv[i] != NULL)
                {
                    if (strcmp(argv[i], "-l") == 0)
                        arr[1]++;
                    if (!strcmp(argv[i], "-a"))
                        arr[2]++;
                    if (!strcmp(argv[i], "-al") || !strcmp(argv[i], "-la"))
                        arr[3]++;
                    i++;
                }
                // printf("%d %d %d ", arr[2], arr[1], arr[3]);
                //printf("%s\n", step);
                if ((arr[1] && arr[2]) || arr[3])
                {
                    fun_lsal(step);
                }
                else
                {
                    if (arr[1] && !arr[2])
                        fun_lsl(step);
                    //printf("jxkc");
                    else if (arr[2] && !arr[1])
                        fun_lsa(step);
                    else
                    {
                        fun_ls(step);
                    }
                }
            }
            // printf("hello\n");
            if (!strcmp(argv[0], "pinfo"))
            {
                int value = 1;
                int sum = 0;
                if (argv[1] != NULL)
                {
                    // printf("%s\n", argv[1]);
                    int value = atoi(argv[1]);
                    // for (int i = strlen(argv[1]) - 1; i >= 0; i--)
                    // {
                    //     printf("%c\n", argv[1][0]);
                    //     sum += (value * (argv[1][i] - '0'));
                    //     value *= 10;
                    // }
                    //  printf("value\n");
                    fun_pinfo(argv, value);
                }
                else
                {
                    //  printf("enter");
                    fun_pinfo(argv, 0);
                }
            }
        }
        if (flag)
        {
            back_gro(argv, flag);
        }
    }
    return 0;
}