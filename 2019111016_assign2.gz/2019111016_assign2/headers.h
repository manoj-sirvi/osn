#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <syscall.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <wait.h>
#include <dirent.h>
#include <time.h>
#include <errno.h>
#include <pwd.h>
#include <grp.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>
#include <setjmp.h>
#include <signal.h>

#define max_command 100
#define MAX_SIZE 1000

struct splite
{
    int temp;
    char **str;
    /* data */
} struc;
void get_name();
char *read1();
void break_command(char *argv);
char *get_shell_dire();
char *check1(char *dire1, char *dire2);
void change_dir(char **argv);
char *dire1;
void echo_cal(char **argv);
void get_pwd(char **argv);
void fun_ls(char *argv);
void fun_lsa(char *argv);
void fun_lsal(char *argv);
void checker(char *file);
void fun_lsl(char *argv);
void back_gro(char **argv, int back);
void fun_pinfo(char **argv, int f);
char hist[25][MAX_SIZE];
void store_history(char *line);
void print_history(int value);
int total_store_history;
char *path_of_history;
int count_line();
void handler(int sig);
int get_history();
