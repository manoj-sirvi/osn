# shell
 Run a shell in c

 # makefile
 1). Run to shell first run 'make'
 2). then run './shell' to enter on console

 # file details

 1). 'shell.c' -: This file run the console for infinite time while it not face   error. and it check for command that which has to run.

 2). 'get_cwd.c' -: In this get the shell directory and change the path of console where we are currently.

 3). 'read_splite.c' -: this file read the user input and parse it into multiple strings.and also reposible to print prompt.

 4). 'background.c' -: This file handle tha background and frontground process and print appropriate message what happen with background process through signal.

 5). 'cd.c' -: handle cd command

 6). 'pwd.c' -: print the path of current working directory

 7). 'echo.c' -:handle echo command

 8). 'handle.c' -: define handler of signal function

 9). 'histor.txt'-: store history in text file

 10). 'history.c' -: store history and print history

 11). 'ls_flag.c' -: implement ls command with flags

 12). 'pinfo.c' -: implemnt of pinfo command which is given a information about process

 
  # command can excuted

  1). ls and it's flag
  2) pwd
  3) cd
  4) echo
  5) background process
  6) pinfo
  7) history
  
