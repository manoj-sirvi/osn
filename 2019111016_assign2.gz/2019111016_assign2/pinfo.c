#include "headers.h"

void fun_pinfo(char **argv, int f)
{
    int pid = 0;
    if (!f)
    {
        pid = getpid();
    }
    else
    {
        pid = f;
    }
    //   printf("%d\n", pid);
    int ans = pid;
    char *path = (char *)calloc(1000, 1);
    char *stat = (char *)calloc(1000, 1);

    strcpy(path, "/proc/");
    strcpy(stat, "/proc/");
    // printf("%s", path);

    char *pid_in_string = (char *)calloc(1000, 1);
    int i = 0;
    // while (pid)
    // {
    //     pid_in_string[i] = (char)((pid % 10) + '0');
    //     i++;
    //     pid /= 10;
    // }
    sprintf(pid_in_string, "%d", pid);
    // printf("%s", pid_in_string);
    // printf("yucgsdcsd\n");
    //printf("%s", path);
    strcat(path, pid_in_string);
    // printf("%s %s\n", stat, path);
    strcat(path, "/exe");
    //fprintf(stdout, "%s %s\n", stat, path);
    strcat(stat, pid_in_string);
    // fprintf(stdout, "%s %s\n", stat, path);
    strcat(stat, "/stat");
    // fprintf(stdout, "%s %s\n", stat, path);

    printf("pid -- %d\n", pid);
    char *actual_path = (char *)calloc(1000, 1);
    int v = readlink(path, actual_path, 1000);
    FILE *fd = fopen(stat, "r");
    if (fd != NULL)
    {

        char status = '0';
        int p;
        char s[1000];
        fscanf(fd, "%d", &p);
        fscanf(fd, "%s", s);
        fscanf(fd, " %c", &status);
        //  printf("enter\n");
        printf("process status -- %c\n", status);
        //  strcat(stat, path);
        fclose(fd);
        strcat(stat, "m");
        FILE *fd1 = fopen(stat, "r");
        
        if (fd1 != NULL)
        {
            int mem;
            fscanf(fd1, "%d", &mem);
            printf("Memory --%d\n", mem);
        }
        else
        {
            perror("Error");
        }
        fclose(fd1);
    }
    else
    {
        perror("Error");
    }

    if (v >= 0)
    {
        printf("Executable Parh -- %s\n", actual_path);
    }
    else
    {
        perror("Error");
    }
}