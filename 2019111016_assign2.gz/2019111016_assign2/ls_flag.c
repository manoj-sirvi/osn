#include "headers.h"

void checker(char *argv)
{
    struct stat sb;

    if (stat(argv, &sb) == 0)
    {
        if (sb.st_mode & S_IRUSR)
            printf("r");
        else
        {
            printf("-");
        }

        if (sb.st_mode & S_IWUSR)
            printf("w");
        else
        {
            printf("-");
        }
        if (sb.st_mode & S_IXUSR)
            printf("x");
        else
        {
            printf("-");
        }
        if (sb.st_mode & S_IRGRP)
            printf("r");
        else
        {
            printf("-");
        }
        if (sb.st_mode & S_IWGRP)
            printf("w");
        else
        {
            printf("-");
        }
        if (sb.st_mode & S_IXGRP)
            printf("x");
        else
        {
            printf("-");
        }
        if (sb.st_mode & S_IROTH)
            printf("r");
        else
        {
            printf("-");
        }
        if (sb.st_mode & S_IWOTH)
            printf("w");
        else
        {
            printf("-");
        }
        if (sb.st_mode & S_IXOTH)
            printf("x");
        else
        {
            printf("-");
        }
    }
}
void fun_lsa(char *argv)
{
    struct dirent **dire;
    int number = scandir(argv, &dire, 0, alphasort);
    //  printf("%d ", no);
    if (number >= 0)
        for (int i = 0; i < number; i++)
        {
            printf("%s\n", dire[i]->d_name);
        }
    else
    {
        printf("Error ");
    }
    for (int i = 0; i < number; i++)
        free(dire[i]);
}
void fun_ls(char *argv)
{
    struct dirent **dire;
    int number = scandir(argv, &dire, 0, alphasort);
    //  printf("%d ", no);
    if (number >= 0)
    {

        for (int i = 0; i < number; i++)
        {
            if (!(strcmp(dire[i]->d_name, ".")) || !(strcmp(dire[i]->d_name, "..")))
                continue;
            printf("%s\n", dire[i]->d_name);
        }
    }
    else
    {
        printf("Error ");
    }
    for (int i = 0; i < number; i++)
        free(dire[i]);
}
void fun_lsal(char *argv)
{
    struct dirent **dire;
    struct stat sb;
    char *time = (char *)malloc(120);
    int number = scandir(argv, &dire, 0, alphasort);
    if (number >= 0)
    {
        for (int i = 0; i < number; i++)
        {

            checker(dire[i]->d_name);
            struct stat sb1;

            if (stat(dire[i]->d_name, &sb1) == 0)
            {
                printf(" %ld ", (sb1.st_ino));
                printf("%s ", (getpwuid(sb1.st_uid))->pw_name);
                printf("%s ", (getgrgid(sb1.st_gid))->gr_name);
                printf("%ld ", (sb1.st_size));
                strftime(time, 14, "%h %d %H:%M", localtime(&sb1.st_mtime));
                printf("%s ", time);
                printf("%s\n", dire[i]->d_name);
            }
        }
    }
    else
    {
        printf("Directory is empty\n");
    }
    for (int i = 0; i < number; i++)
        free(dire[i]);
}
void fun_lsl(char *argv)
{
    struct dirent **dire;
    struct stat sb;
    char *time = (char *)malloc(120);
    int number = scandir(argv, &dire, 0, alphasort);
    if (number >= 0)
    {
        for (int i = 0; i < number; i++)
        {
            if (!strcmp(dire[i]->d_name, ".") || !strcmp(dire[i]->d_name, ".."))
                continue;
            checker(dire[i]->d_name);
            struct stat sb1;

            if (stat(dire[i]->d_name, &sb1) == 0)
            {
                printf(" %ld ", (sb1.st_nlink));
                printf("%s ", (getpwuid(sb1.st_uid))->pw_name);
                printf("%s ", (getgrgid(sb1.st_gid))->gr_name);
                printf("%ld ", (sb1.st_size));
                strftime(time, 14, "%h %d %H:%M", localtime(&sb1.st_mtime));
                printf("%s ", time);
                printf("%s\n", dire[i]->d_name);
            }
        }
    }
    else
    {
        printf("Directory is empty\n");
    }
    for (int i = 0; i < number; i++)
        free(dire[i]);
}
