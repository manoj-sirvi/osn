#include "headers.h"

void handler(int sig)
{
    int status;
//printf("enter");
    int u = waitpid(0, &status, WNOHANG);
   // printf("yes ");
    if (u == -1)
    {
        printf("Error");
    }
    //   printf("exited successfully\n");
    // sprintf(exit, "\nProcess with pid %d exited ", u);
    //  printf("%s ", exit_status);
    if (WIFEXITED(status))
        printf("\nProcess with pid %d exited normally\n", u);
    else if (WIFSIGNALED(status))
    {
        printf("\nprocess ended abnormally\n");
    }
    else if (WIFSTOPPED(status))
        printf("\nProcess stopped\n");
    else
        (EXIT_SUCCESS);
}
