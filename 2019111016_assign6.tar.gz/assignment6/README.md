# socket programming 
 sending a small and large through networking from server to client.

# run code 
- for 1 pc open client directory and server directory in different terminal and then   first run server then run client.
- only single client allow at a same time.
- don't use ctrl c or z to stop client otherwise your code will stuck you may use this for server then for client.


# command allows
- get <file> <file>....
where files are in server directory.
- exit 
use to exit from client
other command not not be used

# implementation
stablize the connection b/w server and client then client ask server for files if file not exist in server and show not exist otherwise staring downloading.
downloading have to be syncronize for this i use send recieve in respective manner.
means if server send something to client then server should wait for acknowledement from client side.

# note
server.c and client.c difinetaly in different directory.