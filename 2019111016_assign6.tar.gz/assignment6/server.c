#include <stdio.h>
#include <strings.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/stat.h>
#define PORT 8000
#define ll long long int
#define chunks 32768
ll findSize(const char *file_name)
{
    struct stat st;
    if (stat(file_name, &st) == 0)
        return (st.st_size);
    else
        return -1;
}
int transfer()
{
}
int main(int argc, char const *argv[])
{
    int server_fd, new_socket, valread;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    // char buffer[1024] = {0};
    char *hello = "1";

    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) // creates socket, SOCK_STREAM is for TCP. SOCK_DGRAM for UDP
    {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // This is to lose the pesky "Address already in use" error message
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                   &opt, sizeof(opt))) // SOL_SOCKET is the socket layer itself
    {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    address.sin_family = AF_INET;         // Address family. For IPv6, it's AF_INET6. 29 others exist like AF_UNIX etc.
    address.sin_addr.s_addr = INADDR_ANY; // Accept connections from any IP address - listens from all interfaces.
    address.sin_port = htons(PORT);       // Server port to open. Htons converts to Big Endian - Left to Right. RTL is Little Endian

    // Forcefully attaching socket to the port 8080
    if (bind(server_fd, (struct sockaddr *)&address,
             sizeof(address)) < 0)
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    // Port bind is done. You want to wait for incoming connections and handle them in some way.
    // The process is two step: first you listen(), then you accept()
    int k = listen(server_fd, 3);
    //printf("%d\n", k);
    if (k < 0) // 3 is the maximum size of queue - connections you haven't accepted
    {
        perror("listen");
        exit(EXIT_FAILURE);
    }
    while (1)
    {
        // returns a brand new socket file descriptor to use for this single accepted connection. Once done, use send and recv
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address,
                                 (socklen_t *)&addrlen)) < 0)
        {
            perror("accept");
            exit(EXIT_FAILURE);
        }
        // valread = read(new_socket, buffer, 1024); // read infromation received into the buffer
        // printf("%s\n", buffer);
        // send(new_socket, hello, strlen(hello), 0); // use sendto() and recvfrom() for DGRAM
        // printf("server-: Hello message sent\n");

        char buffer[1024] = {0};
        char *line = (char *)malloc(1024);
        // char name[] = "1.txt";
        //int fd1 = open(name, O_RDONLY);
        //printf("%d\n", fd1);
        while (1)
        {
            int flag = 0;
            read(new_socket, line, 1024);
            //   printf("%s\n", line);
            char **args = (char **)malloc(1024 * sizeof(char *));
            for (int i = 0; i < 1024; i++)
            {
                args[i] = (char *)malloc(1024 * sizeof(char));
            }
            char *token;
            token = strtok(line, " \n\t");
            args[0] = token;
            int counter = 1;
            while (token != NULL)
            {
                token = strtok(NULL, " \n\t");
                args[counter++] = token;
            }
            args[counter++] = NULL;
            int i = 1;
            if (strcmp("get", args[0]) == 0)
            {
                flag = 1;
            }
            if (strcmp("exit", args[0]) == 0)
            {

                break;
            }
            if (flag)
            {
                while (args[i] != NULL)
                {
                    //  printf("try1\n");
                    char *str = (char *)malloc(2 * chunks);
                    int fd = open(args[i], O_RDONLY);
                    // int fd = open("1.txt", O_RDONLY);
                    // printf("%d\n", fd);

                    if (fd < 0)
                    {
                        perror("error");
                        send(new_socket, "unable", 6, 0);
                        i++;
                        continue;
                    }
                    else
                    {
                        printf("sending a file %s...\n", args[i]);
                        send(new_socket, "able", 4, 0);
                        sleep(3);
                        //  read(new_socket, buffer, 102);

                        int length = findSize(args[i]);
                        char length1[20] = {0};
                        sprintf(length1, "%d", length);
                        send(new_socket, length1, strlen(length1), 0);
                        printf("sended\n");
                        bzero(buffer, strlen(buffer));
                        read(new_socket, buffer, 3);
                        //printf("%s\n", buffer);
                        //break;
                        char *rt = (char *)malloc(1024);
                        if (strcmp(buffer, "hii") == 0)
                        {

                            int done = 0;
                            int f = 0;
                            int count = 0;
                            for (int j = 0; j < 1000000; j++)
                            {
                                //  printf("hiii2\n");
                                if (length - count < chunks)
                                {
                                    read(fd, str, length - count);
                                    //printf("%s\n", str);
                                }
                                else
                                {
                                    // printf("no\n");
                                    read(fd, str, chunks);
                                }
                                send(new_socket, str, strlen(str), 0);
                                count += strlen(str);

                                //printf("%ld\n", strlen(str));
                                //printf("%s\n", str);
                                bzero(str, strlen(str));
                                bzero(rt, strlen(rt));
                                read(new_socket, rt, 4);
                                // printf("%s\n", rt);
                                if (count >= length)
                                {
                                    // printf("otu\n");
                                    // for (int k = 0; k < 100; k++)
                                    // {

                                    send(new_socket, "complete", 8, 0);
                                    // printf("sended\n");
                                    // }
                                    //printf("ha complteted\n");
                                    break;
                                }
                            }
                        }
                    }
                    sleep(4);
                    close(fd);
                    bzero(buffer, strlen(buffer));
                    read(new_socket, buffer, 5);
                    // printf("break\n");
                    i++;
                }
            }
        }
    }
    return 0;
}
