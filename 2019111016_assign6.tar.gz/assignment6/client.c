// Client side C/C++ program to demonstrate Socket programming
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#define PORT 8000
#define chunks 32768
#define ll long long int
ll findSize(const char *file_name)
{
    struct stat st;
    if (stat(file_name, &st) == 0)
        return (st.st_size);
    else
        return -1;
}

int main(int argc, char const *argv[])
{
    struct sockaddr_in address;
    int sock = 0, valread;
    struct sockaddr_in serv_addr;
    char *hello = "1";
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Socket creation error \n");
        return -1;
    }

    memset(&serv_addr, '0', sizeof(serv_addr)); // to make sure the struct is empty. Essentially sets sin_zero as 0
                                                // which is meant to be, and rest is defined below

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    // Converts an IP address in numbers-and-dots notation into either a
    // struct in_addr or a struct in6_addr depending on whether you specify AF_INET or AF_INET6.
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0)
    {
        printf("\nInvalid address/ Address not supported \n");
        return -1;
    }

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) // connect to the server address
    {
        printf("\nConnection Failed \n");
        return -1;
    }
    // fgets(buffer, 1024, stdin);
    // send(sock, buffer, strlen(buffer), 0); // send the message.
    // printf("client -: Hello message sent\n");
    // valread = read(sock, buffer, 1024); // receive message back from server, into the buffer
    // printf("%s\n", buffer);
    size_t value = 0;
    char buffer[1024] = {0};
    char *line = NULL;
    while (1)
    {
        printf("---> ");
        int a = getline(&line, &value, stdin);
        if (a < 0)
        {
            perror("error");
        }

        //   printf("%ld\n", strlen(line));
        if (strlen(line) == 1)
        {
            continue;
        }
        send(sock, line, strlen(line), 0);
        char **args = (char **)malloc(1024 * sizeof(char *));
        for (int i = 0; i < 1024; i++)
        {
            args[i] = (char *)malloc(1024 * sizeof(char));
        }
        char *token;
        token = strtok(line, " \n\t");
        args[0] = token;
        int counter = 1;
        while (token != NULL)
        {
            token = strtok(NULL, " \n\t");
            args[counter++] = token;
        }
        int flag = 0;
        args[counter++] = NULL;
        int i = 1;
        if (strcmp("get", args[0]) == 0)
        {
            flag = 1;
        }
        else if (strcmp(args[0], "exit") == 0)
        {
            return 0;
        }
        else
        {
            if (strcmp(line, "\n") == 0)
            {
                printf("fdhdsj\n");
            }
            printf("please write right command\n");
            continue;
        }

        if (flag)
        {
            while (args[i] != NULL)
            {
                //  printf("try\n");
                bzero(buffer, strlen(buffer));
                read(sock, buffer, 1024);
                // printf("%s\n", buffer);
                char *str = (char *)malloc(chunks + 3);
                if (strcmp(buffer, "unable") == 0)
                {
                    printf("file %s not exist in server\n", args[i]);
                    i++;
                    continue;
                }
                if (strcmp(buffer, "able") == 0)
                {
                    printf("receiving file\n");
                    // send(sock, "tree", 4, 0);

                    char length1[20] = {0};
                    read(sock, length1, 20);
                    printf("recieved\n");
                    long long int length = atol(length1);
                    //  printf("%d\n", length);
                    send(sock, "hii", 3, 0);
                    int fd = open(args[i], O_CREAT | O_RDWR | O_TRUNC, 0600);
                    if (fd < 0)
                    {
                        perror("error:");
                    }
                    long long int count = 0;
                    bzero(buffer, strlen(buffer));
                    for (int j = 0; j < 1000000; j++)
                    {
                        //printf("hii1\n");
                        bzero(str, strlen(str));
                        if (length - count < chunks)
                        {
                            int a = read(sock, str, length - count);
                        }
                        else
                        {

                            int a = read(sock, str, chunks);
                        }
                        // printf("%ld\n", strlen(str));
                        // if (strcmp(str, "complete") == 0)
                        // {
                        //     //  printf("htyty\n");
                        //     break;
                        // }
                        count += strlen(str);
                        printf("%LF\r", ((long double)count * 100) / length);
                        write(fd, str, strlen(str));
                        //  printf("%d\n", count);
                        // printf("%s\n", str);
                        bzero(buffer, strlen(buffer));
                        send(sock, "wait", 4, 0);
                        // printf("hiii\n");
                        if (count >= length)
                        {
                            //  printf("int\n");
                            sleep(1);
                            bzero(buffer, strlen(buffer));
                            read(sock, buffer, 8);
                            //printf("%s\n", buffer);
                            if (strcmp(buffer, "complete") == 0)
                            {
                                //printf("sfgis\n");
                                break;
                            }
                        }
                    }
                    //printf("fygjfer\n");
                    //  sleep(3);
                    //  printf("100.000000\n");
                    close(fd);
                    send(sock, "close", 5, 0);
                    //  printf("fdgvedkv\n");
                }

                //sleep(1);
                //printf("hiiiiiii\n");ge
                printf("\n");
                i++;
                // printf("break\n");
                // break;
            }
        }
    }

    return 0;
}
