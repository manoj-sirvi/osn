General.
       1. path of file and directory can be given in double or single quotes.

         

Q1.
     1. I am making a "Assignment" directory in the same folder which is contain 'Q1.c'.
     2. If "asssignment" directory already exist than just check for file "A.txt" existence. if it's already exist than store the reverse content in this file otherwise create this file and than store.
     3. the percentage of file write can be shown when you don't comment sleep() function.
     4. making the answer file in same folder which is contain a code file.
     5. divide the file into chunk which is equal to power of two and less then file size.

Q2.
     1. If any file for e.g. newfile or oldfile has no read permission than text of this two file is not comparable.

     