#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <syscall.h>
#include <fcntl.h>
#include <sys/types.h>
//#include <math.h>
#include <sys/stat.h>
#include <stdlib.h>
int findSize(const char *file_name)
{
    struct stat st;
    if (stat(file_name, &st) == 0)
        return (st.st_size);
    else
        return -1;
}
void fun(char *string, int count)
{
    struct stat sb;
    stat(string, &sb);
    char arr[3][10] = {"newfile", "oldfile", "Directory"};
    if (sb.st_mode & S_IRUSR)
    {
        printf("User has read permissions on %s: Yes\n", arr[count]);
    }
    else
    {
        printf("User has read permissions on %s: No\n", arr[count]);
    }

    if (sb.st_mode & S_IWUSR)
    {
        printf("User has write permissions on %s: Yes\n", arr[count]);
    }
    else
    {
        printf("User has write permissions on %s: No\n", arr[count]);
    }
    if (sb.st_mode & S_IXUSR)
    {
        printf("User has excute permissions on %s: Yes\n", arr[count]);
    }
    else
    {
        printf("User has excute permissions on %s: No\n", arr[count]);
    }

    if (sb.st_mode & S_IRGRP)
    {
        printf("Group has read permissions on %s: Yes\n", arr[count]);
    }
    else
    {
        printf("Group has read permissions on %s: No\n", arr[count]);
    }
    if (sb.st_mode & S_IWGRP)
    {
        printf("Group has write permissions on %s: Yes\n", arr[count]);
    }
    else
    {
        printf("Group has write permissions on %s: No\n", arr[count]);
    }
    if (sb.st_mode & S_IXGRP)
    {
        printf("Group has excute permissions on %s: Yes\n", arr[count]);
    }
    else
    {
        printf("Group has excute permissions on %s: No\n", arr[count]);
    }

    if (sb.st_mode & S_IROTH)
    {
        printf("Others has read permissions on %s: Yes\n", arr[count]);
    }
    else
    {
        printf("Others has read permissions on %s: No\n", arr[count]);
    }
    if (sb.st_mode & S_IWOTH)
    {
        printf("Others has write permissions on %s: Yes\n", arr[count]);
    }
    else
    {
        printf("Others has write permissions on %s: No\n", arr[count]);
    }
    if (sb.st_mode & S_IXOTH)
    {
        printf("Others has excute permissions on %s: Yes\n", arr[count]);
    }
    else
    {
        printf("Others has excute permissions on %s: No\n", arr[count]);
    }
}
void main(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("command line error\n");
        exit(1);
    }
    struct stat sb;
    int dire_flag = 0;
    if (stat(argv[3], &sb) == 0 && S_ISDIR(sb.st_mode))
    {
        printf("Directory is created: Yes\n");
        dire_flag = 1;
    }
    else
    {
        printf("Directory is created: No\n");
    }
    //int s_file = open(argv[1],);
    int s_file = open(argv[1], O_RDWR, 0777);
    int d_file = open(argv[2], O_RDWR, 0777);
    if (s_file < 0)
    {
        printf("ERROR: newfile don't exist\n");
    }
    if (d_file < 0)
    {
        perror("ERROR: oldfile don't exist\n");
    }
    lseek(s_file, 0, SEEK_SET);
    lseek(d_file, -1, SEEK_END);
    int length1 = findSize(argv[1]);
    int length2 = findSize(argv[2]);
    // printf("%d %d\n", length1, length2);
    int eq_flag = 0;
    if (length1 != length2)
    {
        // printf("Whether file contents are reversed in newfile: No\n");
        eq_flag = 1;
    }
    else
    {
        int prefix_byt_size = (length1) / 100;
        int no_byt_to_read = 1;
        if (prefix_byt_size == 0)
        {
            no_byt_to_read = 1;
        }
        else
        {
            // no_byt_to_read = pow(2, (int)(log((long double)(prefix_byt_size)) / log(2.0)));
            while (no_byt_to_read <= prefix_byt_size)
            {
                no_byt_to_read *= 2;
            }
            no_byt_to_read /= 2;
        }
        //       printf("%lld %lld\n", prefix_byt_size, no_byt_to_read);
        int s = ((length1 - 1) / no_byt_to_read) * no_byt_to_read;
        int length_to_remain_read = length1 - s;
        unsigned char *str1 = (unsigned char *)malloc(no_byt_to_read);
        unsigned char *str2 = (unsigned char *)malloc(no_byt_to_read);
        lseek(d_file, s, SEEK_SET);
        for (int i = 0; i < 1000000000; i++)
        {
            read(d_file, str1, length_to_remain_read);
            read(s_file, str2, length_to_remain_read);
            //printf("%d %d ", length_to_remain_read, no_byt_to_read);
            //printf("%s %s\n", str1, str2);
            int i;
            for (i = 0; i < length_to_remain_read; i++)
            {
                if (str1[length_to_remain_read - i - 1] != str2[i])
                {
                    break;
                }
            }
            if (i != length_to_remain_read)
            {
                eq_flag = 1;
                break;
            }
            int k = lseek(d_file, 0, SEEK_CUR) - no_byt_to_read - length_to_remain_read;
            if (k >= 0)
            {
                int j = -1 * (no_byt_to_read + length_to_remain_read);
                lseek(d_file, j, SEEK_CUR);
                lseek(s_file, 0, SEEK_CUR);
                length_to_remain_read = no_byt_to_read;
            }
            else
            {
                //  printf("dshjhds");
                break;
            }
        }
    }

    if (eq_flag)
    {
        printf("Whether file contents are reversed in newfile: No\n");
    }
    else
    {
        printf("Whether file contents are reversed in newfile: Yes\n");
    }
    if (s_file >= 0)
    {
        fun(argv[1], 0);
        close(s_file);
    }
    if (d_file >= 0)
    {
        fun(argv[2], 1);
        close(d_file);
    }
    if (dire_flag)
        fun(argv[3], 2);

    //getch();
}