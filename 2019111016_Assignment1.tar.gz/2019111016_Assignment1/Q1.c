#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <syscall.h>
#include <fcntl.h>
#include <sys/types.h>
//#include <math.h>
#include <sys/stat.h>
#include <stdlib.h>
#define int long long
int findSize(const char *file_name)
{
    struct stat st;
    if (stat(file_name, &st) == 0)
        return (st.st_size);
    else
        return -1;
}
int main(int argc, char *argv[])
{
    //printf("%d\n", argc);
    if (argc != 2)
    {

        perror("ERROR");
        return (-1);
    }

    int fd = open(argv[1], O_RDWR);
    // FILE *file = fopen(argv[1], "r");
    //int fd = fileno(file);
    int length = findSize(argv[1]);
    char *ans = (char *)malloc(length);
    int l = strlen(argv[1]);
    // printf("%d\n", l);
    //   printf("%lld \n", length);
    read(fd, ans, length);
    //printf("%s\n", ans);
    struct stat st;
    char *direname = (char *)malloc(100);
    char *dir = "Assignment";
    for (int i = 0; i < 10; i++)
        direname[i] = dir[i];
    char *string = (char *)malloc(l + 10);
    for (int i = l - 1; i >= 0; i--)
    {
        if (argv[1][i] == '/')
            break;
        else
        {
            string[l - i - 1] = argv[1][i];
        }
    }
    // printf("%s\n", string);

    int l1 = strlen(string);
    direname[10] = '/';
    for (int i = l1 - 1; i >= 0; i--)
    {
        direname[11 + l1 - i - 1] = string[i];
    }
    // printf("%s\n", direname);
    if (stat(dir, &st) == 0 && S_ISDIR(st.st_mode))
    {
        // printf("sdkjdgv")
    }
    else
    {
        int check = mkdir(dir, 0777);
        //   printf("%d\n", check);
        if (!check)
        {
            mkdir(dir, 0777);
        }
    }
    //printf("ducsdu");

    // printf("%s\n", direname);
    int rev_file = open(direname, O_CREAT | O_RDWR | O_TRUNC, 00700);
    // printf("%d %d", fd, rev_file);
    if (fd < 0 || rev_file < 0)
    {
        perror("ERROR ");
        return (-1);
    }

    int prefix_byt_size = (length) / 100;
    int no_byt_to_read = 1;
    if (prefix_byt_size == 0)
    {
        no_byt_to_read = 1;
    }
    else
    {
        // int b = 0.30102999566;
        //no_byt_to_read = pow(2, (int)(log((long double)(prefix_byt_size)) / log(2.0)));
        while (no_byt_to_read <= prefix_byt_size)
        {
            no_byt_to_read *= 2;
        }
        no_byt_to_read /= 2;
    }
    lseek(fd, -1, SEEK_END);
    lseek(rev_file, 0, SEEK_SET);
    //  printf("%lld %lld\n", prefix_byt_size, no_byt_to_read);
    int s = ((length - 1) / no_byt_to_read) * no_byt_to_read;
    //char *str1, *str2;
    off_t length_to_remain_read = length - s;
    unsigned char *str1 = (unsigned char *)malloc(no_byt_to_read);
    unsigned char *str2 = (unsigned char *)malloc(no_byt_to_read);
    lseek(fd, s, SEEK_SET);
    int count = 0;
    int sum = 0;

    for (int i = 0; i < 1000000000; i++)
    {
        read(fd, str1, length_to_remain_read);
        // printf(" str1=%s  %ld\n", str1, strlen(str1));
        // count++;
        // if (count >= 6 && count <= 8)
        // {
        //     for (int i = 0; i < length_to_remain_read; i++)
        //         printf("%c ", str1[i]);
        // }
        // int l = ftell(file);
        //   printf("%lld\n", l);
        int p = length_to_remain_read - 1;
        sum += length_to_remain_read;
        printf("%Lf\r", ((long double)sum * 100) / length);
        // fflush(stdout);
        //  printf("yes");
        //  sleep(1);
        //   printf("%lld %lld\n", length_to_remain_read, no_byt_to_read);
        for (int i = 0; i < length_to_remain_read; i++)
        {
            str2[i] = (char)str1[p];
            p--;
        }
        // str2[length_to_remain_read] = '\0';
        fflush(stdout);
        //  printf("str2=%s\n", str2);
        write(rev_file, str2, length_to_remain_read);
        int k = lseek(fd, 0, SEEK_CUR) - no_byt_to_read - length_to_remain_read;
        if (k >= 0)
        {
            int j = -1 * (no_byt_to_read + length_to_remain_read);
            lseek(fd, j, SEEK_CUR);
            // printf("%lld\n", k);
            length_to_remain_read = no_byt_to_read;
        }
        else
        {
            break;
        }
    }
    close(fd);
    close(rev_file);
}